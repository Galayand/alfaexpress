<?php
/**
 * Template Name: Alfa Front Page (الرئيسية)
 *
 * Alfa Express Logistics - Comprehensive Front Page Template
 * Features 3D Interactive Hero Game, Trust Stats, About Company, Interactive Route Map,
 * 6 Logistics Services, 8-Step Shipping Workflow, Live Tracking Box, 6 Customer Reviews,
 * 8 Verified Branches with City Filter, Interactive Quote Calculator, FAQs & Blog Preview.
 *
 * @package AlfaExpress
 * @version 3.1.0
 */
get_header();

$branches = alfa_get_branches();
$services = alfa_get_services();
$faqs = alfa_get_faqs();
$reviews = alfa_get_reviews();
?>

<!-- 1. 3D INTERACTIVE HERO SECTION -->
<section id="hero" style="position:relative; min-height:92vh; padding:6.5rem 0 4rem; overflow:hidden; background:radial-gradient(ellipse at top, #0d1a38 0%, #070d1d 75%); display:flex; align-items:center;">
    
    <!-- Ambient Logistics Glow Circles -->
    <div style="position:absolute; top:20%; right:-100px; width:450px; height:450px; background:rgba(227,6,19,0.12); border-radius:50%; filter:blur(90px); pointer-events:none;"></div>
    <div style="position:absolute; bottom:10%; left:-100px; width:400px; height:400px; background:rgba(56,189,248,0.08); border-radius:50%; filter:blur(90px); pointer-events:none;"></div>

    <div class="alfa-container" style="position:relative; z-index:10; width:100%;">
        <div style="display:grid; grid-template-columns:1fr; gap:2.5rem; align-items:center;" class="alfa-hero-main-grid">
            
            <!-- RIGHT COLUMN: HEADLINE, OFFERS & ACTION BUTTONS -->
            <div>
                <!-- Top Verified Experience Tag -->
                <div class="alfa-badge alfa-badge-red" style="margin-bottom:1.25rem; gap:8px;">
                    <span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#e30613; box-shadow:0 0 10px #e30613;"></span>
                    <span>خبرة تزيد عن 15 عاماً في السوق اللوجستي السعودي</span>
                    <span style="background:rgba(227,6,19,0.25); color:#ff8a8a; padding:1px 8px; border-radius:999px; font-size:11px;">من 150 ريال</span>
                </div>

                <h1 style="font-size:clamp(2.1rem, 4.5vw, 3.5rem); font-weight:900; line-height:1.2; color:#ffffff; margin:0 0 1.25rem; letter-spacing:-0.5px;">
                    شحن دولي متكامل <span style="background:linear-gradient(135deg, #ff414d 0%, #e30613 100%); -webkit-background-clip:text; -webkit-text-fill-color:transparent;">من الباب للباب</span> من السعودية إلى أي مكان في مصر
                </h1>

                <p style="font-size:1.05rem; color:#cbd5e1; line-height:1.8; margin-bottom:1.75rem; max-width:580px;">
                    نقل عفش وأثاث منزلي، شحن أغراض شخصية، شاشات وأجهزة كهربائية، وبضائع تجارية مع تخليص جمركي فوري وتغليف احترافي بصناديق خشبية مبطنة لضمان سلامة مقتنياتك 100%.
                </p>

                <!-- Transport Modes Chips -->
                <div style="display:flex; flex-wrap:wrap; gap:0.6rem; margin-bottom:2rem;">
                    <span class="alfa-badge" style="background:#0f1d3a; border-color:rgba(56,189,248,0.3); color:#38bdf8;">✈️ شحن جوي سريع (3-7 أيام)</span>
                    <span class="alfa-badge" style="background:#0f1d3a; border-color:rgba(227,6,19,0.3); color:#ff6b6b;">🚢 شحن بحري حاويات</span>
                    <span class="alfa-badge" style="background:#0f1d3a; border-color:rgba(245,158,11,0.3); color:#fbbf24;">🚛 شحن بري مباشر ومبرد</span>
                </div>

                <!-- Action Buttons -->
                <div style="display:flex; flex-wrap:wrap; gap:0.9rem; margin-bottom:2.25rem;">
                    <a href="<?php echo esc_url(home_url('/quote')); ?>" class="alfa-btn alfa-btn-primary" style="padding:0.9rem 1.85rem; font-size:1rem;">
                        <span>طلب تسعيرة لشحنتك</span>
                        <span>&larr;</span>
                    </a>

                    <a href="<?php echo esc_url(home_url('/tracking')); ?>" class="alfa-btn alfa-btn-outline" style="padding:0.9rem 1.5rem; font-size:1rem;">
                        <span>🔍 تتبع شحنتك المباشر</span>
                    </a>

                    <a href="https://wa.me/<?php echo esc_attr(get_option('alfa_whatsapp', '966501653999')); ?>" target="_blank" class="alfa-btn alfa-btn-whatsapp" style="padding:0.9rem 1.4rem; font-size:1rem;">
                        <span>💬 واتساب الفروع</span>
                    </a>
                </div>

                <!-- Quick Guarantee Stats Strip -->
                <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:1rem; border-top:1px solid rgba(255,255,255,0.08); padding-top:1.25rem;">
                    <div>
                        <span style="font-size:1.4rem; font-weight:900; color:#fff; display:block;">15+ عاماً</span>
                        <span style="font-size:0.75rem; color:#94a3b8;">خبرة لوجستية موثقة</span>
                    </div>
                    <div>
                        <span style="font-size:1.4rem; font-weight:900; color:#e30613; display:block;">8 فروع</span>
                        <span style="font-size:0.75rem; color:#94a3b8;">جدة • مكة • الرياض</span>
                    </div>
                    <div>
                        <span style="font-size:1.4rem; font-weight:900; color:#22c55e; display:block;">100%</span>
                        <span style="font-size:0.75rem; color:#94a3b8;">تغطية لكافة مدن مصر</span>
                    </div>
                </div>
            </div>

            <!-- LEFT COLUMN: FULL 3D INTERACTIVE HERO GAME & CANVAS -->
            <div>
                <div id="alfa-3d-hero-container" style="position:relative; width:100%; height:460px; min-height:460px; border-radius:1.75rem; overflow:hidden; border:1px solid rgba(255,255,255,0.15); background:radial-gradient(ellipse at center, #0a1733 0%, #030712 100%); box-shadow:0 0 50px -10px rgba(227,6,19,0.35); user-select:none;">
                    
                    <!-- TOP GAME HUD BAR -->
                    <div style="position:absolute; top:12px; left:12px; right:12px; z-index:20; display:flex; justify-content:space-between; align-items:center; gap:8px; pointer-events:auto;">
                        
                        <!-- Speedometer -->
                        <div style="display:flex; align-items:center; gap:6px;">
                            <div style="padding:6px 12px; border-radius:14px; background:rgba(0,0,0,0.65); border:1px solid rgba(255,255,255,0.15); backdrop-filter:blur(8px); display:flex; align-items:center; gap:8px;">
                                <span style="color:#38bdf8; font-size:14px;">⚡</span>
                                <div style="text-align:right;">
                                    <span style="display:block; font-size:9px; color:#94a3b8; font-weight:bold;">السرعة اللوجستية</span>
                                    <span style="font-size:12px; font-weight:900; color:#fff; font-family:monospace;">
                                        <span id="alfa-hud-speed">85</span> <span style="font-size:8px; color:#cbd5e1;">كم/س</span>
                                    </span>
                                </div>
                                <span id="alfa-hud-turbo" style="display:none; font-size:8px; font-weight:900; padding:2px 6px; border-radius:4px; background:#e30613; color:#fff;">TURBO</span>
                            </div>

                            <!-- Combo Multiplier -->
                            <div id="alfa-hud-combo" style="display:none; padding:6px 10px; border-radius:14px; background:linear-gradient(to right, #f59e0b, #e30613); color:#fff; font-size:11px; font-weight:900;">
                                2x كومبو!
                            </div>
                        </div>

                        <!-- Score & Reset -->
                        <div style="display:flex; align-items:center; gap:6px;">
                            <div style="padding:6px 12px; border-radius:14px; background:rgba(0,0,0,0.65); border:1px solid rgba(255,255,255,0.15); backdrop-filter:blur(8px); display:flex; align-items:center; gap:6px;">
                                <span style="color:#fbbf24; font-size:13px;">🏆</span>
                                <div style="text-align:right;">
                                    <span style="display:block; font-size:9px; color:#94a3b8; font-weight:bold;">نقاط الشحنات</span>
                                    <span id="alfa-hud-score" style="font-size:12px; font-weight:900; color:#fde047; font-family:monospace;">0</span>
                                </div>
                            </div>

                            <button id="alfa-hud-reset" type="button" title="إعادة تشغيل الرحلة" style="padding:6px 10px; border-radius:14px; background:rgba(0,0,0,0.65); border:1px solid rgba(255,255,255,0.15); color:#cbd5e1; cursor:pointer; font-size:12px;">
                                🔄
                            </button>
                        </div>
                    </div>

                    <!-- FLOATING TOAST -->
                    <div id="alfa-hud-toast" style="display:none; position:absolute; top:65px; left:50%; transform:translateX(-50%); z-index:30; pointer-events:none; padding:6px 16px; border-radius:999px; background:linear-gradient(to right, #e30613, #f59e0b); color:#fff; font-size:11px; font-weight:900; box-shadow:0 10px 20px rgba(227,6,19,0.5); border:1px solid rgba(255,255,255,0.3); backdrop-filter:blur(8px);">
                    </div>

                    <!-- 3D CANVAS MOUNT -->
                    <div id="alfa-3d-canvas-mount" style="width:100%; height:100%; position:relative; cursor:grab;"></div>

                    <!-- LOADING STATE -->
                    <div id="alfa-3d-loading" style="position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; background:#070d1d; z-index:25; gap:10px;">
                        <div style="width:36px; height:36px; border:3px solid #e30613; border-top-color:transparent; border-radius:50%; animation:alfa-spin 1s linear infinite;"></div>
                        <span style="font-size:11px; color:#94a3b8;">جاري إطلاق محرك الشاحنات ثلاثي الأبعاد...</span>
                    </div>

                    <!-- 2D FALLBACK -->
                    <div id="alfa-3d-fallback" style="display:none; position:absolute; inset:0; align-items:center; justify-content:center; background:#070d1d; z-index:15; padding:20px; text-align:center;">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/alfa-car.png" alt="أسطول ألفا إكسبريس" style="max-width:280px; filter:drop-shadow(0 15px 25px rgba(0,0,0,0.8));">
                    </div>

                    <!-- BOTTOM ROUTE PROGRESS HUD (Saudi -> Egypt) -->
                    <div style="position:absolute; bottom:10px; left:10px; right:10px; z-index:20; display:flex; flex-direction:column; gap:6px; pointer-events:auto;">
                        
                        <div style="padding:8px 14px; border-radius:14px; background:rgba(0,0,0,0.75); border:1px solid rgba(255,255,255,0.15); backdrop-filter:blur(10px);">
                            <div style="display:flex; justify-content:space-between; align-items:center; font-size:10px; font-weight:bold; color:#fff; margin-bottom:5px;">
                                <div style="display:flex; align-items:center; gap:6px;">
                                    <span style="color:#e30613;">🧭</span>
                                    <span>المحطة اللوجستية:</span>
                                    <span id="alfa-hud-active-city" style="color:#f59e0b;">🇸🇦 الرياض</span>
                                </div>
                                <span id="alfa-hud-progress-text" style="color:#94a3b8; font-family:monospace;">15% نحو مصر</span>
                            </div>

                            <!-- Progress Track -->
                            <div style="width:100%; height:6px; border-radius:999px; background:rgba(255,255,255,0.1); overflow:hidden;">
                                <div id="alfa-hud-progress-track" style="width:15%; height:100%; border-radius:999px; background:linear-gradient(to right, #e30613, #f59e0b, #22c55e); transition:width 0.3s;"></div>
                            </div>

                            <!-- City Milestones -->
                            <div style="display:flex; justify-content:space-between; font-size:8px; color:#94a3b8; padding-top:4px;">
                                <span>الرياض</span>
                                <span>مكة</span>
                                <span>جدة</span>
                                <span>البحر الأحمر</span>
                                <span>القاهرة</span>
                                <span>الإسكندرية</span>
                            </div>
                        </div>

                        <!-- Steer Helper Bar & Mobile Controls -->
                        <div style="display:flex; justify-content:space-between; align-items:center; padding:4px 10px; border-radius:10px; background:rgba(0,0,0,0.5); border:1px solid rgba(255,255,255,0.08); font-size:9px; color:#cbd5e1; backdrop-filter:blur(6px);">
                            <div style="display:flex; gap:6px;">
                                <button id="alfa-steer-left" type="button" style="padding:2px 8px; border-radius:6px; background:rgba(255,255,255,0.15); color:#fff; font-weight:bold; border:none; cursor:pointer;">◀ يسار</button>
                                <button id="alfa-steer-right" type="button" style="padding:2px 8px; border-radius:6px; background:rgba(255,255,255,0.15); color:#fff; font-weight:bold; border:none; cursor:pointer;">يمين ▶</button>
                            </div>
                            <span style="color:#94a3b8;">🎮 اسحب بالماوس أو الإصبع لتوجيه الشاحنة وجمع الشحنات!</span>
                            <span style="color:#e30613; font-weight:bold;">مرر للتسريع ▼</span>
                        </div>

                    </div>

                </div>
            </div>

        </div>
    </div>
</section>

<style>
@keyframes alfa-spin {
    to { transform: rotate(360deg); }
}
@media(min-width: 1024px) {
    .alfa-hero-main-grid {
        grid-template-columns: 1.15fr 1fr !important;
    }
}
</style>

<!-- 2. TRUST STATS BAR -->
<section style="background:#0b1429; border-top:1px solid rgba(255,255,255,0.08); border-bottom:1px solid rgba(255,255,255,0.08); padding:2.5rem 0;">
    <div class="alfa-container">
        <div class="alfa-grid-4" style="text-align:center;">
            <div>
                <span style="font-size:2.5rem; font-weight:900; color:#fff; display:block; line-height:1;">15+</span>
                <span style="font-size:0.85rem; color:#94a3b8; font-weight:700;">عاماً من الخبرة اللوجستية</span>
            </div>
            <div>
                <span style="font-size:2.5rem; font-weight:900; color:#e30613; display:block; line-height:1;">45,000+</span>
                <span style="font-size:0.85rem; color:#94a3b8; font-weight:700;">شحنة منجزة بنجاح</span>
            </div>
            <div>
                <span style="font-size:2.5rem; font-weight:900; color:#fff; display:block; line-height:1;">8</span>
                <span style="font-size:0.85rem; color:#94a3b8; font-weight:700;">فروع معتمدة بجدة ومكة والرياض</span>
            </div>
            <div>
                <span style="font-size:2.5rem; font-weight:900; color:#38bdf8; display:block; line-height:1;">99.8%</span>
                <span style="font-size:0.85rem; color:#94a3b8; font-weight:700;">نسبة الالتزام بالمواعيد وسلامة الطرود</span>
            </div>
        </div>
    </div>
</section>

<!-- 3. ABOUT COMPANY & LOGISTICS GUARANTEE -->
<section id="about" style="padding:5.5rem 0; background:#070d1d; position:relative; overflow:hidden;">
    <div style="position:absolute; top:50%; left:0; width:350px; height:350px; background:rgba(227,6,19,0.08); border-radius:50%; filter:blur(90px); pointer-events:none;"></div>
    <div class="alfa-container" style="position:relative; z-index:10;">
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:3.5rem; align-items:center;">
            
            <div>
                <div class="alfa-badge alfa-badge-red" style="margin-bottom:1rem;">عن شركة ألفا إكسبريس اللوجستية</div>
                <h2 style="font-size:2.35rem; font-weight:900; color:#fff; margin:0 0 1.25rem; line-height:1.25;">
                    ألفا إكسبريس … <span style="color:#e30613;">نقل ذكي</span> وشريكك اللوجستي الموثوق
                </h2>
                <p style="font-size:1rem; color:#cbd5e1; line-height:1.8; margin-bottom:1rem;">
                    شركة رائدة في مجال الشحن والخدمات اللوجستية، بخبرة تزيد عن 15 عامًا في السوق السعودي، نقدم خدمات شحن احترافية للأفراد والشركات مع التزام كامل بالأمان، السرعة، والدقة في كل مرحلة من مراحل الشحن.
                </p>
                <p style="font-size:0.88rem; color:#94a3b8; line-height:1.8; margin-bottom:2rem;">
                    نعتمد على أنظمة تشغيل مرنة وشبكة فروع متكاملة وفريق عمل مدرّب لتقديم خدمات شحن دقيقة، آمنة، وسريعة. نربط جميع مدن المملكة العربية السعودية بجميع محافظات جمهورية مصر العربية عبر حلول شحن جوي – بحري – بري مدروسة تضمن وصول شحنتك بأعلى مستوى من الجودة.
                </p>

                <!-- 4 Core Pillars -->
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:2rem;">
                    <div style="background:#0b1429; border:1px solid rgba(255,255,255,0.08); border-radius:1rem; padding:1.25rem;">
                        <span style="color:#22c55e; font-size:1.2rem; display:block; margin-bottom:0.25rem;">✓</span>
                        <strong style="color:#fff; font-size:0.95rem; display:block; margin-bottom:4px;">تغطية واسعة شاملة</strong>
                        <span style="font-size:0.75rem; color:#94a3b8; line-height:1.5; display:block;">من كافة مدن المملكة لجميع محافظات مصر وقراها.</span>
                    </div>
                    <div style="background:#0b1429; border:1px solid rgba(255,255,255,0.08); border-radius:1rem; padding:1.25rem;">
                        <span style="color:#e30613; font-size:1.2rem; display:block; margin-bottom:0.25rem;">🛡️</span>
                        <strong style="color:#fff; font-size:0.95rem; display:block; margin-bottom:4px;">صناديق خشبية مبطنة</strong>
                        <span style="font-size:0.75rem; color:#94a3b8; line-height:1.5; display:block;">حماية قصوى للشاشات والأجهزة ضد الكسر والصدمات.</span>
                    </div>
                    <div style="background:#0b1429; border:1px solid rgba(255,255,255,0.08); border-radius:1rem; padding:1.25rem;">
                        <span style="color:#38bdf8; font-size:1.2rem; display:block; margin-bottom:0.25rem;">⚡</span>
                        <strong style="color:#fff; font-size:0.95rem; display:block; margin-bottom:4px;">تخليص جمركي فوري</strong>
                        <span style="font-size:0.75rem; color:#94a3b8; line-height:1.5; display:block;">فريق جمركي مرخص بميناء ضباء ومطار القاهرة.</span>
                    </div>
                    <div style="background:#0b1429; border:1px solid rgba(255,255,255,0.08); border-radius:1rem; padding:1.25rem;">
                        <span style="color:#f59e0b; font-size:1.2rem; display:block; margin-bottom:0.25rem;">📍</span>
                        <strong style="color:#fff; font-size:0.95rem; display:block; margin-bottom:4px;">تسليم لباب المستلم</strong>
                        <span style="font-size:0.75rem; color:#94a3b8; line-height:1.5; display:block;">توصيل مباشر مع التوقيع والإشعار الفوري للمرسل.</span>
                    </div>
                </div>

                <div style="display:flex; gap:1rem; align-items:center; flex-wrap:wrap;">
                    <a href="<?php echo esc_url(home_url('/quote')); ?>" class="alfa-btn alfa-btn-primary">
                        طلب استشارة وتسعيرة مجانية &larr;
                    </a>
                    <a href="tel:<?php echo esc_attr(get_option('alfa_main_phone', '0501653999')); ?>" class="alfa-btn alfa-btn-outline">
                        اتصل بنا: <?php echo esc_html(get_option('alfa_main_phone', '0501653999')); ?>
                    </a>
                </div>
            </div>

            <!-- Left Visual Card -->
            <div>
                <div style="background:#0b1429; border:1px solid rgba(255,255,255,0.12); border-radius:1.75rem; padding:2rem; box-shadow:0 25px 50px rgba(0,0,0,0.5); text-align:center;">
                    <div style="margin-bottom:1.5rem; display:inline-block; padding:1.25rem; border-radius:1.5rem; background:rgba(227,6,19,0.1); border:1px solid rgba(227,6,19,0.3);">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/alfa-logo.webp" alt="ألفا إكسبريس" style="max-height:60px; width:auto; display:block;" onerror="this.onerror=null; this.src='<?php echo get_template_directory_uri(); ?>/assets/images/alfa-car.png';">
                    </div>

                    <h3 style="font-size:1.35rem; font-weight:900; color:#fff; margin:0 0 0.75rem;">
                        ترخيص رسمي ومطابقة لمعايير النقل الدولي
                    </h3>
                    <p style="font-size:0.85rem; color:#94a3b8; line-height:1.7; margin:0 0 1.5rem;">
                        نحن نعمل وفق التراخيص الرسمية الصادرة من الهيئة العامة للنقل بالمملكة العربية السعودية، ونلتزم بالمعايير الدولية لسلامة الشحنات والتخليص الجمركي.
                    </p>

                    <div style="display:flex; justify-content:center; gap:1.5rem; border-top:1px solid rgba(255,255,255,0.08); padding-top:1.25rem; font-size:0.8rem; color:#cbd5e1;">
                        <span>✓ بوليصة شحن قانونية</span>
                        <span>✓ تأمين شامل للمحتويات</span>
                        <span>✓ كادر فني محترف</span>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- 4. INTERACTIVE SAUDI-EGYPT EXPRESS ROUTE MAP -->
<section id="route-map" style="padding:5rem 0; background:#0b1429; border-top:1px solid rgba(255,255,255,0.08); border-bottom:1px solid rgba(255,255,255,0.08);">
    <div class="alfa-container">
        
        <div style="text-align:center; max-width:750px; margin:0 auto 3.5rem;">
            <div class="alfa-badge alfa-badge-red" style="margin-bottom:0.75rem;">شريان النقل اللوجستي المباشر</div>
            <h2 style="font-size:2.35rem; font-weight:900; color:#fff; margin:0 0 1rem;">
                الربط اللوجستي المتكامل <span style="color:#e30613;">بين السعودية ومصر</span>
            </h2>
            <p style="color:#94a3b8; font-size:0.95rem; margin:0;">
                اضغط على أي محطة لوجستية لعرض مواعيد الشحن الجوي والبحري، عدد الفروع، وأرقام التواصل المباشرة.
            </p>
        </div>

        <!-- Interactive Map Grid & Hub Selector -->
        <div style="background:#070d1d; border:1px solid rgba(255,255,255,0.12); border-radius:1.75rem; padding:2rem; box-shadow:0 20px 45px rgba(0,0,0,0.4);">
            
            <!-- Hub Pills Selector -->
            <div style="display:flex; flex-wrap:wrap; gap:0.75rem; justify-content:center; margin-bottom:2rem;" id="alfa-map-city-buttons">
                <button type="button" class="alfa-btn alfa-map-btn active" data-city="jeddah" style="padding:0.6rem 1.25rem; font-size:0.85rem; border-radius:999px; background:#e30613; color:#fff; border:none; cursor:pointer; font-weight:bold;">
                    ⚓ جدة (المقر الرئيسي)
                </button>
                <button type="button" class="alfa-btn alfa-map-btn" data-city="riyadh" style="padding:0.6rem 1.25rem; font-size:0.85rem; border-radius:999px; background:#0f1d3a; color:#cbd5e1; border:1px solid rgba(255,255,255,0.1); cursor:pointer; font-weight:bold;">
                    🇸🇦 الرياض (فرعان)
                </button>
                <button type="button" class="alfa-btn alfa-map-btn" data-city="makkah" style="padding:0.6rem 1.25rem; font-size:0.85rem; border-radius:999px; background:#0f1d3a; color:#cbd5e1; border:1px solid rgba(255,255,255,0.1); cursor:pointer; font-weight:bold;">
                    🕋 مكة المكرمة
                </button>
                <button type="button" class="alfa-btn alfa-map-btn" data-city="cairo" style="padding:0.6rem 1.25rem; font-size:0.85rem; border-radius:999px; background:#0f1d3a; color:#cbd5e1; border:1px solid rgba(255,255,255,0.1); cursor:pointer; font-weight:bold;">
                    🇪🇬 القاهرة والجيزة
                </button>
                <button type="button" class="alfa-btn alfa-map-btn" data-city="alexandria" style="padding:0.6rem 1.25rem; font-size:0.85rem; border-radius:999px; background:#0f1d3a; color:#cbd5e1; border:1px solid rgba(255,255,255,0.1); cursor:pointer; font-weight:bold;">
                    🌊 الإسكندرية والساحل
                </button>
            </div>

            <!-- Active City Hub Card Box -->
            <div id="alfa-map-active-info" style="background:#0b1429; border:1px solid rgba(227,6,19,0.3); border-radius:1.25rem; padding:1.75rem; display:grid; grid-template-columns:repeat(auto-fit, minmax(260px, 1fr)); gap:1.5rem; align-items:center;">
                <div>
                    <span id="alfa-map-city-tag" style="background:rgba(227,6,19,0.15); color:#ff6b6b; padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:bold; display:inline-block; margin-bottom:0.5rem;">الميناء والمطار الرئيسي</span>
                    <h3 id="alfa-map-city-title" style="font-size:1.35rem; font-weight:900; color:#fff; margin:0 0 0.5rem;">جدة (المقر الرئيسي)</h3>
                    <p id="alfa-map-city-desc" style="font-size:0.85rem; color:#94a3b8; line-height:1.7; margin:0 0 0.75rem;">
                        المركز اللوجستي الأكبر والشريان البحري والجوي الذي تنطلق منه جميع رحلات الشحن اليومية إلى الموانئ والمطارات المصرية.
                    </p>
                    <span id="alfa-map-city-branches" style="font-size:0.8rem; color:#38bdf8; font-weight:bold; display:block;">
                        📍 5 فروع بجدة (الفيصلية، السلامة، البوادي، الشرفية، الربوة)
                    </span>
                </div>

                <div style="border-right:1px solid rgba(255,255,255,0.08); padding-right:1.5rem;">
                    <div style="display:flex; flex-direction:column; gap:0.75rem; font-size:0.85rem;">
                        <div style="display:flex; justify-content:space-between;">
                            <span style="color:#94a3b8;">✈️ شحن جوي سريع:</span>
                            <strong id="alfa-map-transit-air" style="color:#38bdf8;">3 - 5 أيام</strong>
                        </div>
                        <div style="display:flex; justify-content:space-between;">
                            <span style="color:#94a3b8;">🚢 شحن بحري حاويات:</span>
                            <strong id="alfa-map-transit-sea" style="color:#4ade80;">7 - 14 يوماً</strong>
                        </div>
                        <div style="display:flex; justify-content:space-between;">
                            <span style="color:#94a3b8;">📞 التواصل والمتابعة:</span>
                            <strong id="alfa-map-phone" style="color:#fff;" dir="ltr">0501653999</strong>
                        </div>
                    </div>

                    <div style="margin-top:1.25rem;">
                        <a href="<?php echo esc_url(home_url('/quote')); ?>" class="alfa-btn alfa-btn-primary" style="width:100%; font-size:0.85rem; padding:0.65rem;">
                            حجز موعد استلام من هذا الفرع
                        </a>
                    </div>
                </div>
            </div>

            <!-- Route Steps Flow -->
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(140px, 1fr)); gap:1rem; margin-top:2rem; text-align:center;">
                <div style="padding:1rem; border-radius:1rem; background:#0b1429; border:1px solid rgba(56,189,248,0.2);">
                    <span style="font-size:1.5rem; display:block; margin-bottom:4px;">🇸🇦</span>
                    <strong style="color:#fff; font-size:0.9rem; display:block;">الرياض ومكة</strong>
                    <span style="font-size:0.7rem; color:#94a3b8;">تجميع ونقل سريع</span>
                </div>
                <div style="padding:1rem; border-radius:1rem; background:#0b1429; border:1px solid rgba(227,6,19,0.3);">
                    <span style="font-size:1.5rem; display:block; margin-bottom:4px;">⚓</span>
                    <strong style="color:#ff6b6b; font-size:0.9rem; display:block;">جدة المركزي</strong>
                    <span style="font-size:0.7rem; color:#cbd5e1;">التغليف والتجهيز</span>
                </div>
                <div style="padding:1rem; border-radius:1rem; background:#070f20; border:1px dashed rgba(56,189,248,0.3);">
                    <span style="font-size:1.5rem; display:block; margin-bottom:4px;">🌊</span>
                    <strong style="color:#38bdf8; font-size:0.9rem; display:block;">البحر الأحمر / الجو</strong>
                    <span style="font-size:0.7rem; color:#94a3b8;">سفن شحن وطيران</span>
                </div>
                <div style="padding:1rem; border-radius:1rem; background:#0b1429; border:1px solid rgba(34,197,94,0.3);">
                    <span style="font-size:1.5rem; display:block; margin-bottom:4px;">🇪🇬</span>
                    <strong style="color:#4ade80; font-size:0.9rem; display:block;">القاهرة والإسكندرية</strong>
                    <span style="font-size:0.7rem; color:#cbd5e1;">تخليص جمركي فوري</span>
                </div>
                <div style="padding:1rem; border-radius:1rem; background:#0b1429; border:1px solid rgba(34,197,94,0.3);">
                    <span style="font-size:1.5rem; display:block; margin-bottom:4px;">🏡</span>
                    <strong style="color:#4ade80; font-size:0.9rem; display:block;">كافة المحافظات</strong>
                    <span style="font-size:0.7rem; color:#94a3b8;">تسليم لباب المستلم</span>
                </div>
            </div>

        </div>

    </div>
</section>

<!-- 5. SERVICES SECTION -->
<section id="services" style="padding:5.5rem 0; background:#070d1d;">
    <div class="alfa-container">
        
        <div style="text-align:center; max-width:700px; margin:0 auto 3.5rem;">
            <div class="alfa-badge alfa-badge-red" style="margin-bottom:0.75rem;">حلول شحن متكاملة ومخصصة</div>
            <h2 style="font-size:2.35rem; font-weight:900; color:#fff; margin:0 0 1rem;">
                خدماتنا <span style="color:#e30613;">اللوجستية المتخصصة</span>
            </h2>
            <p style="color:#94a3b8; font-size:0.95rem; line-height:1.7; margin:0;">
                نوفر أسطولاً متطوراً وحلول شحن بري، بحري، وجوي تغطي كافة الاحتياجات للأفراد والشركات مع التغليف الخشبي والتخليص الجمركي.
            </p>
        </div>

        <div class="alfa-grid-3">
            <?php foreach ($services as $srv): ?>
                <div class="alfa-card" style="display:flex; flex-direction:column; justify-content:space-between;">
                    <div>
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:1rem;">
                            <h3 style="font-size:1.25rem; font-weight:900; color:#fff; margin:0;"><?php echo esc_html($srv['title']); ?></h3>
                            <span style="font-size:0.75rem; color:#ff6b6b; background:rgba(227,6,19,0.15); padding:2px 8px; border-radius:6px; font-weight:bold;">خدمة مميزة</span>
                        </div>
                        <p style="font-size:0.85rem; color:#94a3b8; line-height:1.7; margin:0 0 1.25rem;"><?php echo esc_html($srv['desc']); ?></p>
                        <ul style="list-style:none; padding:0; margin:0 0 1.5rem; font-size:0.82rem; color:#cbd5e1; line-height:2.1;">
                            <?php foreach ($srv['features'] as $f): ?>
                                <li><span style="color:#e30613; margin-left:6px; font-weight:bold;">✓</span> <?php echo esc_html($f); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <a href="<?php echo esc_url(home_url('/quote')); ?>" class="alfa-btn alfa-btn-outline" style="width:100%; font-size:0.85rem; padding:0.65rem;">
                        طلب تسعيرة لهذه الخدمة &larr;
                    </a>
                </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>

<!-- 6. 8-STEP SHIPPING WORKFLOW (HOW IT WORKS) -->
<section id="process" style="padding:5.5rem 0; background:#0b1429; border-top:1px solid rgba(255,255,255,0.08);">
    <div class="alfa-container">
        
        <div style="text-align:center; max-width:700px; margin:0 auto 3.5rem;">
            <div class="alfa-badge alfa-badge-red" style="margin-bottom:0.75rem;">آلية عمل شفافة ومدروسة</div>
            <h2 style="font-size:2.35rem; font-weight:900; color:#fff; margin:0 0 1rem;">
                دورة الشحن من الباب إلى الباب <span style="color:#e30613;">في 8 خطوات واضحة</span>
            </h2>
            <p style="color:#94a3b8; font-size:0.95rem; margin:0;">
                نتبع بروتوكولاً دقيقاً لضمان سرعة الوصول، الحماية التامة، وراحة بالك من اللحظة الأولى.
            </p>
        </div>

        <div class="alfa-grid-4">
            <div class="alfa-card" style="position:relative; overflow:hidden;">
                <span style="position:absolute; top:10px; left:12px; font-size:2.25rem; font-weight:900; color:rgba(255,255,255,0.05); font-family:monospace;">01</span>
                <div style="font-size:1.75rem; margin-bottom:0.75rem;">📱</div>
                <h4 style="font-size:1.1rem; font-weight:900; color:#fff; margin:0 0 0.5rem;">1. طلب التسعيرة والحجز</h4>
                <p style="font-size:0.82rem; color:#94a3b8; line-height:1.7; margin:0;">
                    عبر الموقع الإلكتروني أو واتساب الفروع، يتم تحديد نوع الشحنة، الحجم، وموعد الاستلام المناسب لك.
                </p>
            </div>

            <div class="alfa-card" style="position:relative; overflow:hidden;">
                <span style="position:absolute; top:10px; left:12px; font-size:2.25rem; font-weight:900; color:rgba(255,255,255,0.05); font-family:monospace;">02</span>
                <div style="font-size:1.75rem; margin-bottom:0.75rem;">🚚</div>
                <h4 style="font-size:1.1rem; font-weight:900; color:#fff; margin:0 0 0.5rem;">2. الاستلام من بابك</h4>
                <p style="font-size:0.82rem; color:#94a3b8; line-height:1.7; margin:0;">
                    يصل مندوبنا أو شاحنة الشحن لباب منزلك في جدة، مكة، أو الرياض مع تقديم بوليصة استلام رسمية فورية.
                </p>
            </div>

            <div class="alfa-card" style="position:relative; overflow:hidden;">
                <span style="position:absolute; top:10px; left:12px; font-size:2.25rem; font-weight:900; color:rgba(255,255,255,0.05); font-family:monospace;">03</span>
                <div style="font-size:1.75rem; margin-bottom:0.75rem;">⚖️</div>
                <h4 style="font-size:1.1rem; font-weight:900; color:#fff; margin:0 0 0.5rem;">3. الوزن والمعاينة</h4>
                <p style="font-size:0.82rem; color:#94a3b8; line-height:1.7; margin:0;">
                    وزن إلكتروني دقيق أمام العميل ومراجعة الأغراض للتأكد من مطابقتها للوائح النقل والسلامة.
                </p>
            </div>

            <div class="alfa-card" style="position:relative; overflow:hidden;">
                <span style="position:absolute; top:10px; left:12px; font-size:2.25rem; font-weight:900; color:rgba(255,255,255,0.05); font-family:monospace;">04</span>
                <div style="font-size:1.75rem; margin-bottom:0.75rem;">📦</div>
                <h4 style="font-size:1.1rem; font-weight:900; color:#fff; margin:0 0 0.5rem;">4. التغليف والتبطين الخشبي</h4>
                <p style="font-size:0.82rem; color:#94a3b8; line-height:1.7; margin:0;">
                    تغليف بابلز مقوى وصناديق خشبية مبطنة مخصصة للشاشات والأجهزة الكهربائية ضد الصدمات.
                </p>
            </div>

            <div class="alfa-card" style="position:relative; overflow:hidden;">
                <span style="position:absolute; top:10px; left:12px; font-size:2.25rem; font-weight:900; color:rgba(255,255,255,0.05); font-family:monospace;">05</span>
                <div style="font-size:1.75rem; margin-bottom:0.75rem;">🚢</div>
                <h4 style="font-size:1.1rem; font-weight:900; color:#fff; margin:0 0 0.5rem;">5. الشحن الدولي المباشر</h4>
                <p style="font-size:0.82rem; color:#94a3b8; line-height:1.7; margin:0;">
                    إبحار الحاويات البحرية السريعة عبر البحر الأحمر أو النقل الجوي المباشر إلى مطار القاهرة.
                </p>
            </div>

            <div class="alfa-card" style="position:relative; overflow:hidden;">
                <span style="position:absolute; top:10px; left:12px; font-size:2.25rem; font-weight:900; color:rgba(255,255,255,0.05); font-family:monospace;">06</span>
                <div style="font-size:1.75rem; margin-bottom:0.75rem;">📋</div>
                <h4 style="font-size:1.1rem; font-weight:900; color:#fff; margin:0 0 0.5rem;">6. التخليص الجمركي الفوري</h4>
                <p style="font-size:0.82rem; color:#94a3b8; line-height:1.7; margin:0;">
                    إنهاء كافة الإجراءات الرسمية بواسطة مخلصين جمركيين معتمدين بميناء ضباء والقاهرة دون أي عناء.
                </p>
            </div>

            <div class="alfa-card" style="position:relative; overflow:hidden;">
                <span style="position:absolute; top:10px; left:12px; font-size:2.25rem; font-weight:900; color:rgba(255,255,255,0.05); font-family:monospace;">07</span>
                <div style="font-size:1.75rem; margin-bottom:0.75rem;">🏬</div>
                <h4 style="font-size:1.1rem; font-weight:900; color:#fff; margin:0 0 0.5rem;">7. الفرز والتوجيه بالمستودع</h4>
                <p style="font-size:0.82rem; color:#94a3b8; line-height:1.7; margin:0;">
                    توجيه الشحنات لمراكز التوزيع في القاهرة، الإسكندرية، الدلتا، القناة، وكافة محافظات الصعيد.
                </p>
            </div>

            <div class="alfa-card" style="position:relative; overflow:hidden;">
                <span style="position:absolute; top:10px; left:12px; font-size:2.25rem; font-weight:900; color:rgba(255,255,255,0.05); font-family:monospace;">08</span>
                <div style="font-size:1.75rem; margin-bottom:0.75rem;">🏡</div>
                <h4 style="font-size:1.1rem; font-weight:900; color:#fff; margin:0 0 0.5rem;">8. التسليم لباب المستلم</h4>
                <p style="font-size:0.82rem; color:#94a3b8; line-height:1.7; margin:0;">
                    توصيل الطرد حتى باب المنزل في مصر مع التأكد من سلامة الصناديق والتوقيع على إشعار الاستلام.
                </p>
            </div>
        </div>

    </div>
</section>

<!-- 7. LIVE TRACKING TEASER SECTION -->
<section id="track" style="padding:4rem 0; background:#070d1d; border-top:1px solid rgba(255,255,255,0.08); border-bottom:1px solid rgba(255,255,255,0.08);">
    <div class="alfa-container">
        <div style="background:linear-gradient(135deg, #0e1d3d 0%, #11244d 50%, #0e1d3d 100%); border:1px solid rgba(255,255,255,0.15); border-radius:1.75rem; padding:2.5rem; box-shadow:0 25px 50px rgba(0,0,0,0.4);">
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(300px, 1fr)); gap:2rem; align-items:center;">
                
                <div>
                    <div class="alfa-badge alfa-badge-blue" style="margin-bottom:0.75rem;">بوابة التتبع الرقمي المباشر</div>
                    <h3 style="font-size:1.85rem; font-weight:900; color:#fff; margin:0 0 0.75rem;">
                        لديك رقم شحنة أو بوليصة؟
                    </h3>
                    <p style="font-size:0.9rem; color:#cbd5e1; line-height:1.7; margin:0;">
                        تابع مسار شحنتك لحظة بلحظة منذ استلامها من الفرع بالمملكة وحتى وصولها وتسليمها في مصر.
                    </p>
                </div>

                <div>
                    <form action="<?php echo esc_url(home_url('/tracking')); ?>" method="GET" style="display:flex; gap:0.75rem; flex-wrap:wrap;">
                        <input type="text" name="track_id" placeholder="أدخل رقم البوليصة (مثال: ALF-9921)" dir="ltr" class="alfa-input" style="flex:1; min-width:200px; padding:0.85rem 1.25rem;">
                        <button type="submit" class="alfa-btn alfa-btn-primary" style="padding:0.85rem 1.75rem; white-space:nowrap;">
                            🔍 تتبع الشحنة الآن
                        </button>
                    </form>
                    <div style="font-size:0.75rem; color:#94a3b8; margin-top:0.75rem; display:flex; gap:12px; align-items:center;">
                        <span>✓ تحديث مباشر 24/7</span>
                        <span>✓ إشعارات واتساب فورية</span>
                        <a href="<?php echo esc_url(home_url('/tracking')); ?>" style="color:#38bdf8; text-decoration:none;">صفحة التتبع الشاملة &larr;</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<!-- 8. VERIFIED CUSTOMER REVIEWS (6 AUTHENTIC TESTIMONIALS) -->
<section id="reviews" style="padding:5.5rem 0; background:#070d1d;">
    <div class="alfa-container">
        
        <div style="text-align:center; max-width:700px; margin:0 auto 3.5rem;">
            <div class="alfa-badge alfa-badge-red" style="margin-bottom:0.75rem;">تجارب حقيقية موثقة</div>
            <h2 style="font-size:2.35rem; font-weight:900; color:#fff; margin:0 0 1rem;">
                ماذا يقول عملاؤنا <span style="color:#e30613;">عن خدمات الشحن والتسليم؟</span>
            </h2>
            <p style="color:#94a3b8; font-size:0.95rem; margin:0;">
                نفخر بثقة آلاف العملاء في السعودية ومصر وتقييماتهم الإيجابية الموثقة مع صور الشحنات المستلمة.
            </p>
        </div>

        <div class="alfa-grid-3">
            <?php foreach ($reviews as $rev): ?>
                <div class="alfa-card" style="display:flex; flex-direction:column; justify-content:space-between;">
                    <div>
                        <!-- Header & Route Badge -->
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
                            <span style="font-size:0.75rem; color:#38bdf8; background:rgba(56,189,248,0.1); padding:2px 8px; border-radius:6px; font-weight:bold;">
                                <?php echo esc_html($rev['city']); ?>
                            </span>
                            <div style="color:#f59e0b; font-size:0.9rem;">★★★★★</div>
                        </div>

                        <!-- Review Image Screenshot Preview -->
                        <div style="margin-bottom:1rem; border-radius:0.75rem; overflow:hidden; border:1px solid rgba(255,255,255,0.1); background:#020617;">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/<?php echo esc_attr($rev['image']); ?>" alt="<?php echo esc_attr($rev['name']); ?>" style="width:100%; height:180px; object-fit:cover; display:block;" onerror="this.style.display='none';">
                        </div>

                        <!-- Quote Text -->
                        <p style="font-size:0.85rem; color:#cbd5e1; line-height:1.7; margin:0 0 1rem;">
                            "<?php echo esc_html($rev['comment']); ?>"
                        </p>
                    </div>

                    <!-- Author Details -->
                    <div style="border-top:1px solid rgba(255,255,255,0.08); padding-top:0.75rem; display:flex; justify-content:space-between; align-items:center;">
                        <div>
                            <strong style="color:#fff; font-size:0.9rem; display:block;"><?php echo esc_html($rev['name']); ?></strong>
                            <span style="font-size:0.7rem; color:#94a3b8;"><?php echo esc_html($rev['branch']); ?></span>
                        </div>
                        <span style="font-size:0.7rem; color:#22c55e; background:rgba(34,197,94,0.1); padding:2px 6px; border-radius:4px; font-weight:bold;">✓ عميل موثق</span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>

<!-- 9. 8 VERIFIED BRANCHES (WITH INTERACTIVE CITY FILTER) -->
<section id="branches" style="padding:5.5rem 0; background:#0b1429; border-top:1px solid rgba(255,255,255,0.08);">
    <div class="alfa-container">
        
        <div style="text-align:center; max-width:700px; margin:0 auto 2.5rem;">
            <div class="alfa-badge alfa-badge-red" style="margin-bottom:0.75rem;">شبكة فروعنا بالمملكة</div>
            <h2 style="font-size:2.35rem; font-weight:900; color:#fff; margin:0 0 1rem;">
                8 فروع في <span style="color:#e30613;">جدة، مكة المكرمة، والرياض</span>
            </h2>
            <p style="color:#94a3b8; font-size:0.95rem; margin:0;">
                تفضل بزيارة أقرب فرع إليك أو تواصل معنا للاستلام المباشر من باب منزلك أو مستودعك.
            </p>
        </div>

        <!-- Branch City Filter Tabs -->
        <div style="display:flex; justify-content:center; gap:0.5rem; flex-wrap:wrap; margin-bottom:2.5rem;">
            <button type="button" class="alfa-btn alfa-branch-filter-btn active" data-filter="all" style="padding:0.5rem 1.25rem; font-size:0.8rem; border-radius:999px; background:#e30613; color:#fff; border:none; cursor:pointer; font-weight:bold;">
                جميع الفروع (8)
            </button>
            <button type="button" class="alfa-btn alfa-branch-filter-btn" data-filter="جدة" style="padding:0.5rem 1.25rem; font-size:0.8rem; border-radius:999px; background:#0f1d3a; color:#cbd5e1; border:1px solid rgba(255,255,255,0.1); cursor:pointer; font-weight:bold;">
                جدة (5 فروع)
            </button>
            <button type="button" class="alfa-btn alfa-branch-filter-btn" data-filter="مكة" style="padding:0.5rem 1.25rem; font-size:0.8rem; border-radius:999px; background:#0f1d3a; color:#cbd5e1; border:1px solid rgba(255,255,255,0.1); cursor:pointer; font-weight:bold;">
                مكة المكرمة (فرع 1)
            </button>
            <button type="button" class="alfa-btn alfa-branch-filter-btn" data-filter="الرياض" style="padding:0.5rem 1.25rem; font-size:0.8rem; border-radius:999px; background:#0f1d3a; color:#cbd5e1; border:1px solid rgba(255,255,255,0.1); cursor:pointer; font-weight:bold;">
                الرياض (فرعان)
            </button>
        </div>

        <div class="alfa-grid-4" id="alfa-branches-grid">
            <?php foreach ($branches as $b): ?>
                <div class="alfa-branch-card" data-city="<?php echo esc_attr($b['city']); ?>" style="background:#070d1d; border:1px solid rgba(255,255,255,0.08); border-radius:1.25rem; padding:1.5rem; display:flex; flex-direction:column; justify-content:space-between; transition:all 0.3s;" onmouseover="this.style.borderColor='rgba(227,6,19,0.4)'" onmouseout="this.style.borderColor='rgba(255,255,255,0.08)'">
                    <div>
                        <span style="font-size:0.7rem; background:rgba(227,6,19,0.15); color:#ff6b6b; padding:2px 8px; border-radius:6px; font-weight:bold; display:inline-block; margin-bottom:0.5rem;">
                            <?php echo esc_html($b['city']); ?>
                        </span>
                        <h4 style="font-size:1rem; font-weight:800; color:#fff; margin:0 0 0.5rem;"><?php echo esc_html($b['name']); ?></h4>
                        <p style="font-size:0.75rem; color:#94a3b8; line-height:1.6; margin:0 0 1rem;"><?php echo esc_html($b['address']); ?></p>
                    </div>
                    <div style="border-top:1px solid rgba(255,255,255,0.08); padding-top:0.75rem; display:flex; justify-content:space-between; align-items:center;">
                        <a href="tel:<?php echo esc_attr($b['phone']); ?>" style="color:#fff; font-size:0.85rem; font-weight:bold; font-family:monospace;" dir="ltr"><?php echo esc_html($b['phone']); ?></a>
                        <a href="https://wa.me/966<?php echo substr($b['phone'], 1); ?>" target="_blank" class="alfa-btn alfa-btn-whatsapp" style="padding:0.35rem 0.75rem; font-size:0.7rem;">واتساب</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>

<!-- 10. INSTANT QUOTE CALCULATOR -->
<section id="quote" style="padding:5.5rem 0; background:#070d1d; border-top:1px solid rgba(255,255,255,0.08);">
    <div class="alfa-container" style="max-width:850px;">
        
        <div style="text-align:center; margin-bottom:3rem;">
            <div class="alfa-badge alfa-badge-red" style="margin-bottom:0.75rem;">حاسبة الشحن التفاعلية</div>
            <h2 style="font-size:2.35rem; font-weight:900; color:#fff; margin:0 0 1rem;">
                احسب تكلفة الشحن <span style="color:#e30613;">وأرسل الطلب فوراً عبر واتساب</span>
            </h2>
            <p style="color:#94a3b8; font-size:0.9rem; margin:0;">
                أدخل تفاصيل الشحنة لمعرفة السعر التقديري وسيقوم مندوبنا بالتواصل معك لاستلام الشحنة.
            </p>
        </div>

        <div class="alfa-card" style="padding:2.5rem;">
            <form id="alfa-quote-form">
                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(240px, 1fr)); gap:1.25rem; margin-bottom:1.25rem;">
                    <div>
                        <label style="display:block; font-size:0.8rem; font-weight:bold; color:#cbd5e1; margin-bottom:0.4rem;">مدينة الشحن (السعودية):</label>
                        <select id="alfa-origin" class="alfa-select">
                            <option value="جدة">جدة</option>
                            <option value="مكة المكرمة">مكة المكرمة</option>
                            <option value="الرياض">الرياض</option>
                            <option value="الدمام / الشرقية">الدمام / الشرقية</option>
                            <option value="المدينة المنورة">المدينة المنورة</option>
                        </select>
                    </div>
                    <div>
                        <label style="display:block; font-size:0.8rem; font-weight:bold; color:#cbd5e1; margin-bottom:0.4rem;">محافظة الوصول (مصر):</label>
                        <select id="alfa-destination" class="alfa-select">
                            <option value="القاهرة والجيزة">القاهرة والجيزة</option>
                            <option value="الإسكندرية والبحيرة">الإسكندرية والبحيرة</option>
                            <option value="الدلتا (المنصورة / طنطا / الزقازيق)">محافظات الدلتا</option>
                            <option value="الصعيد (أسيوط / سوهاج / قنا / الأقصر)">محافظات الصعيد</option>
                            <option value="القناة (السويس / الإسماعيلية / بورسعيد)">محافظات القناة</option>
                        </select>
                    </div>
                </div>

                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(240px, 1fr)); gap:1.25rem; margin-bottom:1.25rem;">
                    <div>
                        <label style="display:block; font-size:0.8rem; font-weight:bold; color:#cbd5e1; margin-bottom:0.4rem;">نوع الشحنة:</label>
                        <select id="alfa-service-type" class="alfa-select">
                            <option value="أغراض شخصية وحقائب">أغراض شخصية وحقائب</option>
                            <option value="أثاث وعفش منزلي">أثاث وعفش منزلي</option>
                            <option value="أجهزة كهربائية وشاشات">أجهزة كهربائية وشاشات</option>
                            <option value="بضائع تجارية">بضائع تجارية</option>
                            <option value="شحن جوي سريع">شحن جوي مستعجل</option>
                        </select>
                    </div>
                    <div>
                        <label style="display:block; font-size:0.8rem; font-weight:bold; color:#cbd5e1; margin-bottom:0.4rem;">الوزن التقديري (كجم):</label>
                        <input type="number" id="alfa-weight" class="alfa-input" value="30" min="5" max="5000">
                    </div>
                </div>

                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(240px, 1fr)); gap:1.25rem; margin-bottom:1.5rem;">
                    <div>
                        <label style="display:block; font-size:0.8rem; font-weight:bold; color:#cbd5e1; margin-bottom:0.4rem;">اسمك الكريم:</label>
                        <input type="text" id="alfa-sender-name" class="alfa-input" placeholder="مثال: أحمد محمد" required>
                    </div>
                    <div>
                        <label style="display:block; font-size:0.8rem; font-weight:bold; color:#cbd5e1; margin-bottom:0.4rem;">رقم الجوال:</label>
                        <input type="tel" id="alfa-sender-phone" class="alfa-input" placeholder="05xxxxxxxx" required>
                    </div>
                </div>

                <button type="submit" class="alfa-btn alfa-btn-primary" style="width:100%; padding:0.9rem; font-size:1rem;">
                    احسب التكلفة وأرسل عبر واتساب
                </button>
            </form>

            <!-- Result Box -->
            <div id="alfa-calc-result" style="display:none; margin-top:1.5rem; background:rgba(227,6,19,0.08); border:1px solid rgba(227,6,19,0.3); border-radius:1.25rem; padding:1.5rem; text-align:center;">
                <span style="font-size:0.8rem; color:#94a3b8; display:block; margin-bottom:0.25rem;">التكلفة التقديرية للشحنة:</span>
                <span id="alfa-estimated-price" style="font-size:1.75rem; font-weight:900; color:#fff; display:block; margin-bottom:0.5rem;"></span>
                <span style="font-size:0.85rem; color:#38bdf8; display:block; margin-bottom:1.25rem;">مدة التوصيل المقدرة: <strong id="alfa-estimated-duration"></strong></span>
                <a id="alfa-send-whatsapp-btn" href="#" target="_blank" class="alfa-btn alfa-btn-whatsapp" style="font-size:0.95rem; padding:0.75rem 1.75rem;">
                    💬 تأكيد الطلب وحجز موعد استلام عبر واتساب
                </a>
            </div>

        </div>

    </div>
</section>

<!-- 11. FAQS SECTION -->
<section id="faq" style="padding:5.5rem 0; background:#0b1429; border-top:1px solid rgba(255,255,255,0.08);">
    <div class="alfa-container" style="max-width:850px;">
        
        <div style="text-align:center; margin-bottom:3.5rem;">
            <div class="alfa-badge alfa-badge-red" style="margin-bottom:0.75rem;">إجابات واضحة وشفافة</div>
            <h2 style="font-size:2.35rem; font-weight:900; color:#fff; margin:0 0 1rem;">
                الأسئلة <span style="color:#e30613;">الشائعة</span>
            </h2>
            <p style="color:#94a3b8; font-size:0.95rem; margin:0;">
                أهم التساؤلات حول مواعيد الشحن، التغليف، الأوراق المطلوبة، وإجراءات التخليص الجمركي.
            </p>
        </div>

        <div>
            <?php foreach ($faqs as $faq): ?>
                <details class="alfa-faq-item">
                    <summary>
                        <span><?php echo esc_html($faq['q']); ?></span>
                        <span style="color:#e30613; font-size:1.25rem;">+</span>
                    </summary>
                    <div class="alfa-faq-content">
                        <?php echo esc_html($faq['a']); ?>
                    </div>
                </details>
            <?php endforeach; ?>
        </div>

        <div style="text-align:center; margin-top:2.5rem;">
            <a href="<?php echo esc_url(home_url('/faq')); ?>" class="alfa-btn alfa-btn-outline">
                عرض جميع الأسئلة ومركز المساعدة الشامل &larr;
            </a>
        </div>

    </div>
</section>

<!-- 12. LATEST LOGISTICS GUIDES & BLOG -->
<section id="blog" style="padding:5.5rem 0; background:#070d1d; border-top:1px solid rgba(255,255,255,0.08);">
    <div class="alfa-container">
        
        <div style="display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:3rem; flex-wrap:wrap; gap:1rem;">
            <div>
                <div class="alfa-badge alfa-badge-red" style="margin-bottom:0.5rem;">دليل الشحن والجمارك</div>
                <h2 style="font-size:2.25rem; font-weight:900; color:#fff; margin:0;">
                    أحدث <span style="color:#e30613;">المقالات والإرشادات</span>
                </h2>
            </div>
            <a href="<?php echo esc_url(home_url('/blog')); ?>" class="alfa-btn alfa-btn-outline" style="font-size:0.85rem; padding:0.6rem 1.25rem;">
                تصفح كافة المقالات &larr;
            </a>
        </div>

        <?php
        $recent_posts = new WP_Query(array(
            'posts_per_page' => 3,
            'post_status'    => 'publish',
        ));
        ?>

        <div class="alfa-grid-3">
            <?php if ($recent_posts->have_posts()): ?>
                <?php while ($recent_posts->have_posts()): $recent_posts->the_post(); ?>
                    <article class="alfa-card" style="padding:0; overflow:hidden; display:flex; flex-direction:column; justify-content:space-between;">
                        <div>
                            <?php if (has_post_thumbnail()): ?>
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail('medium_large', array('style' => 'width:100%; height:200px; object-fit:cover; display:block;')); ?>
                                </a>
                            <?php else: ?>
                                <div style="height:200px; background:#0f1d3a; display:flex; align-items:center; justify-content:center; color:#38bdf8; font-size:2.5rem;">
                                    📦
                                </div>
                            <?php endif; ?>
                            <div style="padding:1.5rem;">
                                <span style="font-size:0.75rem; color:#e30613; font-weight:bold; display:block; margin-bottom:0.5rem;">
                                    <?php echo get_the_date(); ?>
                                </span>
                                <h3 style="font-size:1.15rem; font-weight:800; color:#fff; margin:0 0 0.75rem;">
                                    <a href="<?php the_permalink(); ?>" style="color:#fff; text-decoration:none;">
                                        <?php the_title(); ?>
                                    </a>
                                </h3>
                                <p style="font-size:0.85rem; color:#94a3b8; line-height:1.7; margin:0;">
                                    <?php echo wp_trim_words(get_the_excerpt(), 18); ?>
                                </p>
                            </div>
                        </div>
                        <div style="padding:0 1.5rem 1.5rem;">
                            <a href="<?php the_permalink(); ?>" style="color:#e30613; font-weight:bold; font-size:0.85rem; text-decoration:none;">
                                قراءة المقال كاملاً &larr;
                            </a>
                        </div>
                    </article>
                <?php endwhile; wp_reset_postdata(); ?>
            <?php else: ?>
                <!-- Static Fallback Cards if blog posts not seeded yet -->
                <div class="alfa-card">
                    <span style="font-size:0.75rem; color:#e30613; font-weight:bold; display:block; margin-bottom:0.5rem;">إرشادات الجمارك</span>
                    <h3 style="font-size:1.15rem; font-weight:800; color:#fff; margin:0 0 0.75rem;">دليل التخليص الجمركي للشحنات من السعودية إلى مصر 2026</h3>
                    <p style="font-size:0.85rem; color:#94a3b8; line-height:1.7; margin:0 0 1rem;">تعرف على الأوراق المطلوبة وقائمة الأجهزة المسموحة والإعفاءات الجمركية للأغراض الشخصية.</p>
                    <a href="<?php echo esc_url(home_url('/blog')); ?>" style="color:#e30613; font-weight:bold; font-size:0.85rem;">قراءة المزيد &larr;</a>
                </div>
                <div class="alfa-card">
                    <span style="font-size:0.75rem; color:#e30613; font-weight:bold; display:block; margin-bottom:0.5rem;">نصائح التغليف</span>
                    <h3 style="font-size:1.15rem; font-weight:800; color:#fff; margin:0 0 0.75rem;">كيف تغلف الشاشات والأجهزة الكهربائية بأمان تام للشحن الدولي؟</h3>
                    <p style="font-size:0.85rem; color:#94a3b8; line-height:1.7; margin:0 0 1rem;">أهمية الصناديق الخشبية المبطنة وطبقات البابلز لحماية الشاشات الذكية من الصدمات.</p>
                    <a href="<?php echo esc_url(home_url('/blog')); ?>" style="color:#e30613; font-weight:bold; font-size:0.85rem;">قراءة المزيد &larr;</a>
                </div>
                <div class="alfa-card">
                    <span style="font-size:0.75rem; color:#e30613; font-weight:bold; display:block; margin-bottom:0.5rem;">شحن العفش والأثاث</span>
                    <h3 style="font-size:1.15rem; font-weight:800; color:#fff; margin:0 0 0.75rem;">خطوات نقل الأثاث المنزلي من جدة والرياض إلى المحافظات المصرية</h3>
                    <p style="font-size:0.85rem; color:#94a3b8; line-height:1.7; margin:0 0 1rem;">من التفكيك والترقيم والتغليف حتى التركيب في باب منزلك بمصر مع الضمان الشامل.</p>
                    <a href="<?php echo esc_url(home_url('/blog')); ?>" style="color:#e30613; font-weight:bold; font-size:0.85rem;">قراءة المزيد &larr;</a>
                </div>
            <?php endif; ?>
        </div>

    </div>
</section>

<?php get_footer(); ?>
