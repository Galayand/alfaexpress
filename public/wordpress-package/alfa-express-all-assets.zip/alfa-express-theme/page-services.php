<?php
/**
 * Template Name: خدمات الشحن (Services)
 * Template Post Type: page
 */
get_header();

$services = alfa_get_services();
?>

<div style="padding:4rem 0 6rem; background:#070d1d; min-height:80vh;">
    <div class="alfa-container">
        
        <!-- Header Banner -->
        <div style="text-align:center; max-width:750px; margin:0 auto 4rem;">
            <div class="alfa-badge alfa-badge-red" style="margin-bottom:1rem;">حلول لوجستية معتمدة</div>
            <h1 style="font-size:clamp(2rem, 4vw, 3rem); font-weight:900; color:#fff; margin:0 0 1rem;">
                خدمات الشحن من <span style="color:#e30613;">السعودية إلى مصر</span>
            </h1>
            <p style="color:#cbd5e1; font-size:1.05rem; line-height:1.8;">
                نقدم خدمات شحن شاملة تغطي كافة الاحتياجات للأفراد والشركات مع التغليف الاحترافي والتخليص الجمركي والتسليم حتى باب المنزل.
            </p>
        </div>

        <!-- Services Detailed Grid -->
        <div class="alfa-grid-3" style="gap:2rem; margin-bottom:4rem;">
            <?php foreach ($services as $srv): ?>
                <div class="alfa-card" style="display:flex; flex-direction:column; justify-content:space-between;">
                    <div>
                        <span style="font-size:1.5rem; background:rgba(227,6,19,0.15); width:48px; height:48px; border-radius:12px; display:inline-flex; align-items:center; justify-content:center; margin-bottom:1.25rem;">📦</span>
                        <h2 style="font-size:1.35rem; font-weight:900; color:#fff; margin:0 0 1rem;"><?php echo esc_html($srv['title']); ?></h2>
                        <p style="font-size:0.9rem; color:#94a3b8; line-height:1.7; margin-bottom:1.5rem;"><?php echo esc_html($srv['desc']); ?></p>
                        
                        <div style="border-top:1px solid rgba(255,255,255,0.08); padding-top:1rem; margin-bottom:1.5rem;">
                            <strong style="color:#fff; font-size:0.85rem; display:block; margin-bottom:0.5rem;">أبرز مزايا الخدمة:</strong>
                            <ul style="list-style:none; padding:0; margin:0; font-size:0.8rem; color:#cbd5e1; line-height:2;">
                                <?php foreach ($srv['features'] as $feat): ?>
                                    <li><span style="color:#e30613; margin-left:6px;">✓</span> <?php echo esc_html($feat); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>

                    <a href="<?php echo esc_url(home_url('/quote')); ?>" class="alfa-btn alfa-btn-primary" style="width:100%; font-size:0.85rem; padding:0.75rem;">
                        طلب عرض سعر لهذه الخدمة &larr;
                    </a>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Call to Action Banner -->
        <div style="background:linear-gradient(135deg, #0b1429 0%, #16223f 100%); border:1px solid rgba(255,255,255,0.12); border-radius:1.75rem; padding:3rem; text-align:center;">
            <h3 style="font-size:1.75rem; font-weight:900; color:#fff; margin:0 0 1rem;">هل تبحث عن خدمة مخصصة لشحنتك؟</h3>
            <p style="color:#cbd5e1; font-size:0.95rem; max-width:600px; margin:0 auto 1.5rem;">
                فريق خدمة عملاء ألفا إكسبريس متاح على مدار الساعة لتلقي استفساراتكم وترتيب استلام الشحنة من باب بيتك في جدة ومكة والرياض.
            </p>
            <div style="display:flex; justify-content:center; gap:1rem; flex-wrap:wrap;">
                <a href="https://wa.me/<?php echo esc_attr(get_option('alfa_whatsapp', '966501653999')); ?>" target="_blank" class="alfa-btn alfa-btn-whatsapp">
                    تحدث معنا عبر واتساب مباشرة
                </a>
                <a href="tel:<?php echo esc_attr(get_option('alfa_main_phone', '0501653999')); ?>" class="alfa-btn alfa-btn-outline" dir="ltr">
                    📞 <?php echo esc_html(get_option('alfa_main_phone', '0501653999')); ?>
                </a>
            </div>
        </div>

    </div>
</div>

<?php get_footer(); ?>
