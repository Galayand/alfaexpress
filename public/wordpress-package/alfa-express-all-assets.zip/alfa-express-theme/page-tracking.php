<?php
/**
 * Template Name: تتبع الشحنة (Tracking)
 * Template Post Type: page
 */
get_header();
?>

<div style="padding:4rem 0 6rem; background:#070d1d; min-height:80vh;">
    <div class="alfa-container" style="max-width:750px;">
        
        <!-- Header Banner -->
        <div style="text-align:center; margin-bottom:3.5rem;">
            <div class="alfa-badge alfa-badge-red" style="margin-bottom:1rem;">بوابة الاستعلام والمتابعة المباشرة</div>
            <h1 style="font-size:clamp(2rem, 4vw, 3rem); font-weight:900; color:#fff; margin:0 0 1rem;">
                تتبع <span style="color:#e30613;">شحنتك المباشر</span>
            </h1>
            <p style="color:#cbd5e1; font-size:1.05rem; line-height:1.8;">
                أدخل رقم البوليصة أو كود التتبع المستلم عند الشحن لمتابعة خط سير الشحنة لحظة بلحظة حتى تسليمها.
            </p>
        </div>

        <!-- Tracking Form Card -->
        <div class="alfa-card" style="padding:2.5rem;">
            <form id="alfa-tracking-form">
                <label style="display:block; font-size:0.9rem; font-weight:bold; color:#cbd5e1; margin-bottom:0.75rem;">
                    رقم بوليصة الشحن (Tracking Number):
                </label>
                <div style="display:flex; gap:0.75rem; flex-wrap:wrap;">
                    <input type="text" id="alfa-tracking-code" class="alfa-input" placeholder="مثال: ALF-2026-8890" style="flex:1; min-width:220px;" required>
                    <button type="submit" class="alfa-btn alfa-btn-primary" style="padding:0.85rem 1.75rem;">
                        🔍 تتبع الشحنة
                    </button>
                </div>
            </form>

            <div id="alfa-tracking-result" style="display:none;"></div>
        </div>

        <!-- Direct Tracking System CTA -->
        <div style="margin-top:2.5rem; background:#0b1429; border:1px solid rgba(255,255,255,0.08); border-radius:1.5rem; padding:1.75rem; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:1rem;">
            <div>
                <strong style="color:#fff; font-size:1rem; display:block; margin-bottom:0.25rem;">بوابة نظام التتبع الخارجي</strong>
                <span style="color:#94a3b8; font-size:0.8rem;">يمكنك أيضاً تسجيل الدخول على البوابة المركزية الرسمية.</span>
            </div>
            <a href="https://tracking.alfa-express.com" target="_blank" class="alfa-btn alfa-btn-outline" style="font-size:0.85rem;">
                فتح البوابة الرسمية ↗
            </a>
        </div>

    </div>
</div>

<?php get_footer(); ?>
