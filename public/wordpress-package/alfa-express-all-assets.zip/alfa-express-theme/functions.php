<?php
/**
 * Alfa Express Logistics - Standalone WordPress Theme Functions
 *
 * @package AlfaExpress
 * @version 3.0.0
 */

if (!defined('ABSPATH')) exit;

// 1. THEME SETUP
function alfa_theme_setup() {
    // Add default title tag support
    add_theme_support('title-tag');

    // Add support for Post Thumbnails / Featured Images
    add_theme_support('post-thumbnails');

    // Add support for Custom Logo
    add_theme_support('custom-logo', array(
        'height'      => 80,
        'width'       => 240,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    // HTML5 markup support
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));

    // Register Navigation Menus
    register_nav_menus(array(
        'primary' => __('القائمة الرئيسية (Header Menu)', 'alfa-express'),
        'footer'  => __('قائمة روابط الفوتر (Footer Menu)', 'alfa-express'),
    ));
}
add_action('after_setup_theme', 'alfa_theme_setup');

// 2. ENQUEUE SCRIPTS & STYLES
function alfa_theme_scripts() {
    // Google Cairo Font
    wp_enqueue_style('alfa-cairo-font', 'https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800;900&display=swap', array(), null);

    // Theme main stylesheet
    wp_enqueue_style('alfa-main-style', get_stylesheet_uri(), array(), '3.0.0');

    // Custom Theme UI stylesheet
    wp_enqueue_style('alfa-custom-css', get_template_directory_uri() . '/assets/css/alfa-theme.css', array('alfa-cairo-font'), '3.0.0');

    // Three.js Engine for 3D Hero Game
    wp_enqueue_script('threejs', get_template_directory_uri() . '/assets/js/three.min.js', array(), 'r128', true);

    // Theme interactive JavaScript bundle
    wp_enqueue_script('alfa-custom-js', get_template_directory_uri() . '/assets/js/alfa-theme.js', array('jquery'), '3.0.0', true);

    // 3D Hero Scene Engine
    wp_enqueue_script('alfa-3d-hero', get_template_directory_uri() . '/assets/js/alfa-3d-hero.js', array('threejs', 'alfa-custom-js'), '3.0.0', true);

    // Localize Script with dynamic company settings
    wp_localize_script('alfa-custom-js', 'alfaThemeConfig', array(
        'ajaxurl'   => admin_url('admin-ajax.php'),
        'phone'     => get_option('alfa_main_phone', '0501653999'),
        'whatsapp'  => get_option('alfa_whatsapp', '966501653999'),
        'homeUrl'   => home_url('/'),
        'themeUrl'  => get_template_directory_uri(),
    ));
}
add_action('wp_enqueue_scripts', 'alfa_theme_scripts');

// 3. LOAD ONE-TIME ALL-IN-ONE IMPORTER
if (is_admin()) {
    require_once get_template_directory() . '/admin/class-alfa-one-time-importer.php';
}

// 4. HELPER DATA FUNCTIONS
function alfa_get_reviews() {
    return array(
        array(
            'id' => 1,
            'name' => 'م. إبراهيم عبد العزيز',
            'city' => 'الرياض -> القاهرة',
            'branch' => 'فرع العزيزية - الرياض',
            'rating' => 5,
            'image' => 'review-1.jpeg',
            'type' => 'شحن عفش وأجهزة كهربائية',
            'comment' => 'تجربة ممتازة جداً مع ألفا إكسبريس. تم شحن غرفة نوم وشاشتين 65 بوصة في صناديق خشبية مبطنة، ووصلت بحالة الوكالة لباب المنزل في مصر دون أي خدش أو مصاريف جمركية مفاجئة.'
        ),
        array(
            'id' => 2,
            'name' => 'د. سارة محمود',
            'city' => 'جدة -> الإسكندرية',
            'branch' => 'فرع الفيصلية (الرئيسي) - جدة',
            'rating' => 5,
            'image' => 'review-2.jpeg',
            'type' => 'أغراض شخصية وكتب طبية',
            'comment' => 'شحن سريع والتزام مذهل بالمواعيد. استلموا الحقائب والصناديق من باب شقتي بجدة، والتسليم كان في سموحة بالإسكندرية خلال 12 يوماً فقط مع التغليف المحكم.'
        ),
        array(
            'id' => 3,
            'name' => 'أ. طارق عبد العليم',
            'city' => 'جدة -> المنصورة (الدلتا)',
            'branch' => 'فرع البوادي - شارع قريش',
            'rating' => 5,
            'image' => 'review-3.jpeg',
            'type' => 'شاشات ذكية وغسالة أوتوماتيك',
            'comment' => 'أفضل شركة شحن تعاملت معها على الإطلاق. التغليف بصناديق خشبية للشاشات والأجهزة يعطيك راحة بال تامة، وموظفي خدمة العملاء في قمة الاحترام والمتابعة.'
        ),
        array(
            'id' => 4,
            'name' => 'أ. حسام الدين عبد الرحمن',
            'city' => 'مكة المكرمة -> أسيوط',
            'branch' => 'فرع مكة المكرمة (الشوقية)',
            'rating' => 5,
            'image' => 'review-4.jpeg',
            'type' => 'عفش وأثاث منزلي متكامل',
            'comment' => 'شحنت عفش بيتي بالكامل من مكة إلى أسيوط. فريق النجارين فكوا العفش ورقموا القطع بحرفية، وتم التوصيل والتسليم حتى باب البيت في الصعيد مع بوليصة رسمية وتتبع دقيق.'
        ),
        array(
            'id' => 5,
            'name' => 'م. وائل النجار',
            'city' => 'الرياض -> الجيزة (أكتوبر)',
            'branch' => 'فرع الملز - الرياض',
            'rating' => 5,
            'image' => 'review-5.jpeg',
            'type' => 'شحن جوي مستعجل لوثائق وبضائع',
            'comment' => 'خدمة الشحن الجوي سريعة جداً ووصلت خلال 4 أيام عمل لمطار القاهرة ومنها لمدينة 6 أكتوبر. شكراً لفريق ألفا إكسبريس على المصداقية العالية.'
        ),
        array(
            'id' => 6,
            'name' => 'أ. محمد فهمي',
            'city' => 'جدة -> السويس والقناة',
            'branch' => 'فرع السلامة - صقر قريش',
            'rating' => 5,
            'image' => 'review-6.jpeg',
            'type' => 'أجهزة مطبخ وشاشات',
            'comment' => 'أسعارهم واضحة ومنافسة وموظف الاستلام جاء على الموعد بالضبط وقام بوزن الطرود أمامي. بوليصة التتبع واضحة ومحدثة أولاً بأول. بارك الله فيكم.'
        ),
    );
}

// 4. HELPER DATA FUNCTIONS
function alfa_get_branches() {
    return array(
        array('city' => 'جدة', 'name' => 'فرع جدة - البوادي', 'phone' => '0580906241', 'address' => 'حي البوادي - شارع قريش - جدة', 'maps' => 'https://maps.google.com/?q=21.5833,39.1667'),
        array('city' => 'جدة', 'name' => 'فرع جدة - السلامة', 'phone' => '0591627623', 'address' => 'حي السلامة - شارع صقر قريش - جدة', 'maps' => 'https://maps.google.com/?q=21.5900,39.1550'),
        array('city' => 'جدة', 'name' => 'فرع جدة - الفيصلية (المقر الرئيسي)', 'phone' => '0509133390', 'address' => '4275 الروضة - حي الفيصلية - جدة', 'maps' => 'https://maps.google.com/?q=21.5700,39.1750'),
        array('city' => 'جدة', 'name' => 'فرع جدة - الشرفية', 'phone' => '0578710493', 'address' => 'حي الشرفية - طريق المدينة المنورة - جدة', 'maps' => 'https://maps.google.com/?q=21.5200,39.1900'),
        array('city' => 'جدة', 'name' => 'فرع جدة - الربوة', 'phone' => '0539595508', 'address' => 'حي الربوة - شارع حراء - جدة', 'maps' => 'https://maps.google.com/?q=21.6100,39.1800'),
        array('city' => 'مكة المكرمة', 'name' => 'فرع مكة المكرمة', 'phone' => '0567133390', 'address' => 'مكة المكرمة - مخطط الشوقية / الرصيفة', 'maps' => 'https://maps.google.com/?q=21.3891,39.8579'),
        array('city' => 'الرياض', 'name' => 'فرع الرياض - العزيزية', 'phone' => '0539595799', 'address' => 'حي العزيزية - طريق النصر - الرياض', 'maps' => 'https://maps.google.com/?q=24.5900,46.7700'),
        array('city' => 'الرياض', 'name' => 'فرع الرياض - الملز', 'phone' => '0539595117', 'address' => 'حي الملز - شارع صلاح الدين الأيوبي - الرياض', 'maps' => 'https://maps.google.com/?q=24.6600,46.7300'),
    );
}

function alfa_get_services() {
    return array(
        array(
            'id' => 'personal',
            'title' => 'شحن الأغراض الشخصية والحقائب',
            'desc' => 'شحن سريع ومضمون للملابس، الحقائب، والهدايا مع تغليف احترافي وتسليم عند باب المستلم في كافة المحافظات.',
            'features' => array('تغليف ضد الرطوبة والأتربة', 'تسليم من الباب للباب', 'إمكانية التأمين على الشحنة')
        ),
        array(
            'id' => 'furniture',
            'title' => 'شحن الأثاث والعفش المنزلي',
            'desc' => 'فك وتغليف ونقل غرف النوم، الصالونات، والمطابخ بأيدي نجارين وفنيين محترفين مع صناديق خشبية مبطنة.',
            'features' => array('فنيين ونجارين فك وتركيب', 'تغليف بابلز وكرتون مقوى', 'شحن بري وبحري مباشر')
        ),
        array(
            'id' => 'appliances',
            'title' => 'شحن الأجهزة الكهربائية والشاشات',
            'desc' => 'شحن آمن للشاشات والتلفزيونات والغسالات والثلاجات مع صناديق خشبية مصممة خصيصاً للحماية من الصدمات.',
            'features' => array('صناديق خشبية مصممة هندسياً', 'فحص وتجربة قبل الاستلام', 'ضمان سلامة الوصول 100%')
        ),
        array(
            'id' => 'commercial',
            'title' => 'شحن البضائع والطرود التجارية',
            'desc' => 'حلول لوجستية متكاملة لقطاع الأعمال والتجار والمصانع مع متابعة بوالص جمركية وتخليص سريع بالموانئ.',
            'features' => array('تخليص جمركي معتمد', 'إصدار فوري للبوالص', 'أسعار خاصة للأوزان الكبيرة')
        ),
        array(
            'id' => 'customs',
            'title' => 'التخليص الجمركي المعتمد',
            'desc' => 'إنهاء كافة المعاملات والمستندات الجمركية في ميناء ضباء، نويبع، ميناء الإسكندرية، ومطار القاهرة.',
            'features' => array('فريق قانوني جمركي خبير', 'تجنب أي مصاريف مفاجئة', 'سرعة إفراج استثنائية')
        ),
        array(
            'id' => 'air',
            'title' => 'الشحن الجوي السريع Express',
            'desc' => 'خدمة الشحن الجوي المستعجل للطرود والوثائق الهامة من مطار الملك عبدالعزيز ومطار الملك خالد لمطار القاهرة.',
            'features' => array('وصول خلال 3-7 أيام', 'أولوية شحن ومعالجة', 'تتبع دقيق لحظة بلحظة')
        ),
    );
}

function alfa_get_faqs() {
    return array(
        array('q' => 'ما هي مدة الشحن من السعودية إلى مصر؟', 'a' => 'الشحن الجوي يستغرق بين 3 إلى 7 أيام عمل، بينما الشحن البحري والبري يتراوح بين 10 إلى 20 يوماً وصولاً لباب منزلك في كافة المحافظات.'),
        array('q' => 'هل توفرون خدمة التغليف والفك بالمنازل؟', 'a' => 'نعم، نوفر فنيين ونجارين لفك العفش وتغليفه بطبقات حماية ثلاثية وصناديق خشبية للشاشات والأجهزة الحساسة.'),
        array('q' => 'ما هي الأوراق المطلوبة للشحن والتخليص الجمركي؟', 'a' => 'صورة جواز السفر أو الرقم القومي للمستلم في مصر، وصورة هوية أو إقامة المرسل بالسعودية، مع قائمة تقريبية بالمحتويات.'),
        array('q' => 'هل يوجد تتبع مباشر للشحنة؟', 'a' => 'نعم، فور تسليم الشحنة تستلم بوليصة تحتوي على رقم تتبع لمتابعة خط سير الشحنة لحظياً عبر صفحة التتبع في الموقع.'),
        array('q' => 'ما هي فروعكم في المملكة العربية السعودية؟', 'a' => 'لدينا 8 فروع رسمية: 5 فروع في جدة (الفيصلية، البوادي، السلامة، الشرفية، الربوة)، فرع في مكة المكرمة (الشوقية/الرصيفة)، وفرعان في الرياض (العزيزية، الملز).'),
        array('q' => 'كيف يتم احتساب سعر الشحن؟', 'a' => 'يتم الحساب بناءً على الوزن الفعلي، الحجم، نوع البضاعة (عفش، كهربائيات، أغراض شخصية)، ومدينة التسليم في مصر.'),
    );
}
