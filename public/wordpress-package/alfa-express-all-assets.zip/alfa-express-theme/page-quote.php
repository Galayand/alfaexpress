<?php
/**
 * Template Name: طلب عرض سعر (Quote)
 * Template Post Type: page
 */
get_header();
?>

<div style="padding:4rem 0 6rem; background:#070d1d; min-height:80vh;">
    <div class="alfa-container" style="max-width:850px;">
        
        <!-- Header Banner -->
        <div style="text-align:center; margin-bottom:3.5rem;">
            <div class="alfa-badge alfa-badge-red" style="margin-bottom:1rem;">حاسبة الأسعار الفورية</div>
            <h1 style="font-size:clamp(2rem, 4vw, 3rem); font-weight:900; color:#fff; margin:0 0 1rem;">
                طلب عرض سعر <span style="color:#e30613;">وحساب تكلفة الشحن</span>
            </h1>
            <p style="color:#cbd5e1; font-size:1.05rem; line-height:1.8;">
                حدد تفاصيل شحنتك لمعرفة التكلفة التقديرية بدقة وحجز موعد استلام فوري من باب منزلك أو مستودعك.
            </p>
        </div>

        <!-- Calculator Form Card -->
        <div class="alfa-card" style="padding:2.5rem;">
            <form id="alfa-quote-form">
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:1.25rem; margin-bottom:1.25rem;">
                    <div>
                        <label style="display:block; font-size:0.85rem; font-weight:bold; color:#cbd5e1; margin-bottom:0.4rem;">مدينة الاستلام (السعودية):</label>
                        <select id="alfa-origin" class="alfa-select">
                            <option value="جدة">جدة (فروعنا 5)</option>
                            <option value="مكة المكرمة">مكة المكرمة</option>
                            <option value="الرياض">الرياض (العزيزية / الملز)</option>
                            <option value="الدمام والخبر">الدمام والخبر</option>
                            <option value="المدينة المنورة">المدينة المنورة</option>
                            <option value="الطائف">الطائف</option>
                        </select>
                    </div>
                    <div>
                        <label style="display:block; font-size:0.85rem; font-weight:bold; color:#cbd5e1; margin-bottom:0.4rem;">محافظة التسليم (مصر):</label>
                        <select id="alfa-destination" class="alfa-select">
                            <option value="القاهرة والجيزة">القاهرة والجيزة</option>
                            <option value="الإسكندرية والبحيرة">الإسكندرية والبحيرة</option>
                            <option value="محافظات الدلتا">محافظات الدلتا (المنصورة / طنطا / الشرقية)</option>
                            <option value="محافظات الصعيد">محافظات الصعيد (أسيوط / سوهاج / قنا / الأقصر)</option>
                            <option value="مدن القناة">مدن القناة (السويس / الإسماعيلية / بورسعيد)</option>
                        </select>
                    </div>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:1.25rem; margin-bottom:1.25rem;">
                    <div>
                        <label style="display:block; font-size:0.85rem; font-weight:bold; color:#cbd5e1; margin-bottom:0.4rem;">نوع الشحنة:</label>
                        <select id="alfa-service-type" class="alfa-select">
                            <option value="أغراض شخصية وحقائب">أغراض شخصية وحقائب</option>
                            <option value="أثاث وعفش منزلي">أثاث وعفش منزلي (غرف نوم / صالونات)</option>
                            <option value="شاشات وأجهزة كهربائية">شاشات وأجهزة كهربائية (تغليف خشبي)</option>
                            <option value="بضائع تجارية وطرود">بضائع تجارية وطرود للشركات</option>
                            <option value="شحن جوي سريع مستعجل">شحن جوي سريع مستعجل (3-7 أيام)</option>
                        </select>
                    </div>
                    <div>
                        <label style="display:block; font-size:0.85rem; font-weight:bold; color:#cbd5e1; margin-bottom:0.4rem;">الوزن التقديري (كجم):</label>
                        <input type="number" id="alfa-weight" class="alfa-input" value="40" min="5" max="10000">
                    </div>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:1.25rem; margin-bottom:1.5rem;">
                    <div>
                        <label style="display:block; font-size:0.85rem; font-weight:bold; color:#cbd5e1; margin-bottom:0.4rem;">الاسم الكريم:</label>
                        <input type="text" id="alfa-sender-name" class="alfa-input" placeholder="اسمك الكريم" required>
                    </div>
                    <div>
                        <label style="display:block; font-size:0.85rem; font-weight:bold; color:#cbd5e1; margin-bottom:0.4rem;">رقم الجوال:</label>
                        <input type="tel" id="alfa-sender-phone" class="alfa-input" placeholder="05xxxxxxxx" required>
                    </div>
                </div>

                <button type="submit" class="alfa-btn alfa-btn-primary" style="width:100%; padding:1rem; font-size:1.05rem;">
                    احسب التكلفة التقديرية وأرسل الطلب
                </button>
            </form>

            <!-- Result Box -->
            <div id="alfa-calc-result" style="display:none; margin-top:2rem; background:rgba(227,6,19,0.08); border:1px solid rgba(227,6,19,0.3); border-radius:1.5rem; padding:2rem; text-align:center;">
                <span style="font-size:0.85rem; color:#94a3b8; display:block; margin-bottom:0.25rem;">التكلفة التقديرية للشحن:</span>
                <span id="alfa-estimated-price" style="font-size:2rem; font-weight:900; color:#fff; display:block; margin-bottom:0.5rem;"></span>
                <span style="font-size:0.9rem; color:#38bdf8; display:block; margin-bottom:1.5rem;">المدة المقدرة للوصول والتسليم: <strong id="alfa-estimated-duration"></strong></span>
                <a id="alfa-send-whatsapp-btn" href="#" target="_blank" class="alfa-btn alfa-btn-whatsapp" style="font-size:1rem; padding:0.85rem 2rem;">
                    💬 تأكيد الطلب وحجز موعد عبر واتساب
                </a>
            </div>

        </div>

    </div>
</div>

<?php get_footer(); ?>
