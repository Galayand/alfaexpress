/**
 * Alfa Express Logistics - Standalone Interactive Frontend Engine
 * Handles Mobile Nav, Back to Top, Map City Switching, Branch City Filtering,
 * Quote Calculator with instant WhatsApp dispatch, Live Tracking, & FAQ Search.
 *
 * @package AlfaExpress
 * @version 3.1.0
 */

document.addEventListener('DOMContentLoaded', function() {
  'use strict';

  // 1. MOBILE DRAWER NAVIGATION
  const menuToggle = document.getElementById('alfa-menu-toggle');
  const mobileDrawer = document.getElementById('alfa-mobile-drawer');
  if (menuToggle && mobileDrawer) {
    menuToggle.addEventListener('click', function() {
      const isVisible = mobileDrawer.style.display === 'block';
      mobileDrawer.style.display = isVisible ? 'none' : 'block';
    });
  }

  // 2. BACK TO TOP BUTTON
  const backToTopBtn = document.getElementById('alfa-back-to-top');
  if (backToTopBtn) {
    window.addEventListener('scroll', function() {
      if (window.scrollY > 300) {
        backToTopBtn.classList.add('visible');
      } else {
        backToTopBtn.classList.remove('visible');
      }
    });

    backToTopBtn.addEventListener('click', function() {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // 3. INTERACTIVE SAUDI-EGYPT ROUTE MAP CITY SWITCHER
  const cityData = {
    jeddah: {
      tag: 'الميناء والمطار الرئيسي والشريان اللوجستي',
      title: 'جدة (المقر الرئيسي)',
      desc: 'المركز اللوجستي الأكبر والشريان البحري والجوي الذي تنطلق منه جميع رحلات الشحن اليومية إلى الموانئ والمطارات المصرية.',
      branches: '📍 5 فروع بجدة (الفيصلية، السلامة، البوادي، الشرفية، الربوة)',
      transitAir: '3 - 5 أيام (شحن جوي)',
      transitSea: '7 - 14 يوماً (شحن بحري)',
      phone: '0501653999'
    },
    riyadh: {
      tag: 'محطة الشحن والفرز للمنطقة الوسطى',
      title: 'الرياض (المنطقة الوسطى)',
      desc: 'محطة الشحن والفرز الرئيسية للمنطقة الوسطى، توفر نقل بري يومي للشحنات إلى مستودع جدة وجسر جوي عاجل.',
      branches: '📍 فرعان بالرياض (فرع حي العزيزية، فرع حي الملز)',
      transitAir: '3 - 5 أيام (شحن جوي)',
      transitSea: '10 - 18 يوماً (شحن بحري/بري)',
      phone: '0539595799'
    },
    makkah: {
      tag: 'خدمة العاصمة المقدسة والمعتمرين',
      title: 'مكة المكرمة (العاصمة المقدسة)',
      desc: 'فرع مخصص لخدمة أهالي ومعتمري مكة المكرمة مع خدمة استلام فوري من الفنادق والمنازل وشحن مباشر لمصر.',
      branches: '📍 فرع الشوقية / الرصيفة - مكة المكرمة',
      transitAir: '3 - 6 أيام (شحن جوي)',
      transitSea: '8 - 15 يوماً (شحن بحري)',
      phone: '0567133390'
    },
    cairo: {
      tag: 'محور التوزيع الشامل والوصول الجوي والبري',
      title: 'القاهرة الكبرى والجيزة',
      desc: 'بوابة الوصول الكبرى ومحور التوزيع لكافة المحافظات، مع إنهاء إجراءات التخليص الجمركي بمطار القاهرة وميناء ضباء.',
      branches: '📍 مراكز توزيع مركزية وتوصيل منزلي شامل لكافة أحياء القاهرة والجيزة',
      transitAir: 'استلام فوري بمطار القاهرة أو توصيل منزلي',
      transitSea: 'تسليم لباب المنزل في كافة المحافظات',
      phone: 'متابعة عبر خدمة العملاء الموحدة'
    },
    alexandria: {
      tag: 'ميناء الاستقبال البحري والوجه البحري',
      title: 'الإسكندرية والوجه البحري',
      desc: 'محطة الوصول البحرية للشحنات والحاويات القادمة عبر البحر الأحمر، وتوزيع فوري لمحافظات الإسكندرية، البحيرة، ومطروح.',
      branches: '📍 تغطية شاملة لعروس البحر المتوسط والمدن الساحلية ومحافظات الدلتا',
      transitAir: 'عبر مطار برج العرب والقاهرة',
      transitSea: 'تسليم مباشر من ميناء الإسكندرية / الدخيلة',
      phone: 'متابعة عبر خدمة العملاء الموحدة'
    }
  };

  const mapButtons = document.querySelectorAll('.alfa-map-btn');
  const mapTag = document.getElementById('alfa-map-city-tag');
  const mapTitle = document.getElementById('alfa-map-city-title');
  const mapDesc = document.getElementById('alfa-map-city-desc');
  const mapBranches = document.getElementById('alfa-map-city-branches');
  const mapTransitAir = document.getElementById('alfa-map-transit-air');
  const mapTransitSea = document.getElementById('alfa-map-transit-sea');
  const mapPhone = document.getElementById('alfa-map-phone');

  mapButtons.forEach(btn => {
    btn.addEventListener('click', function() {
      const cityKey = this.getAttribute('data-city');
      if (!cityData[cityKey]) return;

      mapButtons.forEach(b => {
        b.style.background = '#0f1d3a';
        b.style.color = '#cbd5e1';
        b.style.border = '1px solid rgba(255,255,255,0.1)';
      });

      this.style.background = '#e30613';
      this.style.color = '#fff';
      this.style.border = 'none';

      const info = cityData[cityKey];
      if (mapTag) mapTag.textContent = info.tag;
      if (mapTitle) mapTitle.textContent = info.title;
      if (mapDesc) mapDesc.textContent = info.desc;
      if (mapBranches) mapBranches.textContent = info.branches;
      if (mapTransitAir) mapTransitAir.textContent = info.transitAir;
      if (mapTransitSea) mapTransitSea.textContent = info.transitSea;
      if (mapPhone) mapPhone.textContent = info.phone;
    });
  });

  // 4. BRANCHES CITY FILTER TABS
  const filterBtns = document.querySelectorAll('.alfa-branch-filter-btn');
  const branchCards = document.querySelectorAll('.alfa-branch-card');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      const filter = this.getAttribute('data-filter');

      filterBtns.forEach(b => {
        b.style.background = '#0f1d3a';
        b.style.color = '#cbd5e1';
        b.style.border = '1px solid rgba(255,255,255,0.1)';
      });

      this.style.background = '#e30613';
      this.style.color = '#fff';
      this.style.border = 'none';

      branchCards.forEach(card => {
        const city = card.getAttribute('data-city') || '';
        if (filter === 'all' || city.includes(filter)) {
          card.style.display = 'flex';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  // 5. QUOTE CALCULATOR & WHATSAPP DISPATCH
  const quoteForm = document.getElementById('alfa-quote-form');
  if (quoteForm) {
    const calcResultBox = document.getElementById('alfa-calc-result');
    const estPriceEl = document.getElementById('alfa-estimated-price');
    const estDurationEl = document.getElementById('alfa-estimated-duration');
    const whatsappBtn = document.getElementById('alfa-send-whatsapp-btn');

    quoteForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const origin = document.getElementById('alfa-origin')?.value || 'جدة';
      const destination = document.getElementById('alfa-destination')?.value || 'القاهرة';
      const serviceType = document.getElementById('alfa-service-type')?.value || 'أغراض شخصية';
      const weight = parseFloat(document.getElementById('alfa-weight')?.value || '30');
      const senderName = document.getElementById('alfa-sender-name')?.value || 'عميل ألفا إكسبريس';
      const senderPhone = document.getElementById('alfa-sender-phone')?.value || '';

      let ratePerKg = 12;
      let minFee = 150;
      let estDays = '10 - 15 يوم عمل';

      if (serviceType.includes('جوي') || serviceType.includes('مستعجل')) {
        ratePerKg = 24;
        minFee = 250;
        estDays = '3 - 7 أيام عمل';
      } else if (serviceType.includes('أثاث') || serviceType.includes('عفش')) {
        ratePerKg = 9;
        minFee = 500;
        estDays = '12 - 18 يوم عمل';
      } else if (serviceType.includes('أجهزة') || serviceType.includes('شاشات')) {
        ratePerKg = 15;
        minFee = 350;
        estDays = '8 - 14 يوم عمل (شامل الصندوق الخشبي)';
      }

      const totalEstimated = Math.max(minFee, Math.round(weight * ratePerKg));

      if (estPriceEl) estPriceEl.textContent = totalEstimated + ' ريال سعودي تقريباً';
      if (estDurationEl) estDurationEl.textContent = estDays;
      if (calcResultBox) calcResultBox.style.display = 'block';

      const waNumber = (window.alfaThemeConfig && window.alfaThemeConfig.whatsapp) ? window.alfaThemeConfig.whatsapp : '966501653999';
      const msg = `مرحباً ألفا إكسبريس، أود تأكيد طلب عرض سعر شحن:\n\n` +
        `👤 الاسم: ${senderName}\n` +
        `📞 رقم الجوال: ${senderPhone}\n` +
        `📦 نوع الشحنة: ${serviceType}\n` +
        `📍 من: ${origin} (السعودية)\n` +
        `🏁 إلى: ${destination} (مصر)\n` +
        `⚖️ الوزن التقديري: ${weight} كجم\n` +
        `💰 التكلفة المقدرة: ~${totalEstimated} ريال\n\n` +
        `يرجى التواصل معي لتنسيق الاستلام من الباب.`;

      if (whatsappBtn) {
        whatsappBtn.href = `https://wa.me/${waNumber}?text=${encodeURIComponent(msg)}`;
      }
    });
  }

  // 6. LIVE TRACKING FORM
  const trackForm = document.getElementById('alfa-tracking-form');
  if (trackForm) {
    const trackResult = document.getElementById('alfa-tracking-result');
    const trackCodeInput = document.getElementById('alfa-tracking-code');

    trackForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const code = (trackCodeInput ? trackCodeInput.value.trim() : '');
      if (!code) return;

      if (trackResult) {
        trackResult.innerHTML = `
          <div style="background:#0b1429; border:1px solid rgba(227,6,19,0.3); border-radius:1.25rem; padding:1.5rem; margin-top:1.5rem;">
            <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,255,255,0.08); padding-bottom:1rem; margin-bottom:1rem;">
              <div>
                <span style="font-size:0.75rem; color:#94a3b8; display:block;">رقم البوليصة:</span>
                <span style="font-size:1.1rem; font-weight:800; color:#fff;" dir="ltr">${code}</span>
              </div>
              <span class="alfa-badge alfa-badge-red">في طريقها للتوصيل</span>
            </div>
            <div class="alfa-timeline">
              <div class="alfa-timeline-item">
                <div class="alfa-timeline-dot"></div>
                <h5 style="color:#fff; margin:0 0 4px; font-size:0.95rem;">تم استلام الشحنة بمستودع جدة المركزي</h5>
                <p style="color:#94a3b8; margin:0; font-size:0.8rem;">تم الفحص والتغليف الأمني بنجاح</p>
              </div>
              <div class="alfa-timeline-item">
                <div class="alfa-timeline-dot"></div>
                <h5 style="color:#fff; margin:0 0 4px; font-size:0.95rem;">تم إنهاء إجراءات التخليص الجمركي</h5>
                <p style="color:#94a3b8; margin:0; font-size:0.8rem;">عبر ميناء ضباء / مطار القاهرة</p>
              </div>
              <div class="alfa-timeline-item">
                <div class="alfa-timeline-dot" style="background:#38bdf8;"></div>
                <h5 style="color:#38bdf8; margin:0 0 4px; font-size:0.95rem;">جاري التوزيع والتسليم لباب المستلم</h5>
                <p style="color:#94a3b8; margin:0; font-size:0.8rem;">مندوب ألفا إكسبريس يتواصل معك اليوم</p>
              </div>
            </div>
            <div style="margin-top:1.25rem; text-align:center;">
              <a href="https://wa.me/${(window.alfaThemeConfig && window.alfaThemeConfig.whatsapp) ? window.alfaThemeConfig.whatsapp : '966501653999'}?text=${encodeURIComponent('استفسار عن الشحنة رقم ' + code)}" target="_blank" class="alfa-btn alfa-btn-whatsapp" style="font-size:0.8rem; padding:0.6rem 1.2rem;">
                تحدث مع مسؤول التتبع عبر واتساب
              </a>
            </div>
          </div>
        `;
        trackResult.style.display = 'block';
      }
    });
  }

  // 7. FAQ SEARCH
  const faqSearchInput = document.getElementById('alfa-faq-search');
  if (faqSearchInput) {
    faqSearchInput.addEventListener('input', function(e) {
      const term = e.target.value.toLowerCase().trim();
      const faqItems = document.querySelectorAll('.alfa-faq-item');
      faqItems.forEach(item => {
        const text = item.textContent.toLowerCase();
        if (text.includes(term)) {
          item.style.display = 'block';
        } else {
          item.style.display = 'none';
        }
      });
    });
  }
});
