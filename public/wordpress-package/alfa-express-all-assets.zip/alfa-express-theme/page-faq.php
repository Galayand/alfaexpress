<?php
/**
 * Template Name: الأسئلة الشائعة (FAQ)
 * Template Post Type: page
 */
get_header();

$faqs = alfa_get_faqs();

// JSON-LD Schema for Google SEO Rich Snippets
$faq_schema = array(
    '@context' => 'https://schema.org',
    '@type'    => 'FAQPage',
    'mainEntity' => array()
);

foreach ($faqs as $f) {
    $faq_schema['mainEntity'][] = array(
        '@type' => 'Question',
        'name'  => $f['q'],
        'acceptedAnswer' => array(
            '@type' => 'Answer',
            'text'  => $f['a']
        )
    );
}
?>

<script type="application/ld+json">
<?php echo json_encode($faq_schema, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); ?>
</script>

<div style="padding:4rem 0 6rem; background:#070d1d; min-height:80vh;">
    <div class="alfa-container" style="max-width:850px;">
        
        <!-- Header Banner -->
        <div style="text-align:center; margin-bottom:3.5rem;">
            <div class="alfa-badge alfa-badge-red" style="margin-bottom:1rem;">مركز المساعدة والدعم الفني</div>
            <h1 style="font-size:clamp(2rem, 4vw, 3rem); font-weight:900; color:#fff; margin:0 0 1rem;">
                الأسئلة <span style="color:#e30613;">الشائعة</span>
            </h1>
            <p style="color:#cbd5e1; font-size:1.05rem; line-height:1.8;">
                إجابات تفصيلية ودقيقة عن كافة التساؤلات المتعلقة بالشحن من السعودية لمصر، إجراءات الجمارك، التغليف، وتتبع الشحنات.
            </p>
        </div>

        <!-- Live Instant Search Bar -->
        <div style="margin-bottom:2.5rem;">
            <div style="position:relative;">
                <input type="text" id="alfa-faq-search" class="alfa-input" placeholder="ابحث في الأسئلة (مثال: جمارك، تغليف، مدة الشحن، أثاث)..." style="padding:1rem 1.5rem; font-size:1rem; border-radius:1.25rem;">
            </div>
        </div>

        <!-- FAQ Accordion List -->
        <div id="alfa-faq-list">
            <?php foreach ($faqs as $faq): ?>
                <details class="alfa-faq-item">
                    <summary>
                        <span><?php echo esc_html($faq['q']); ?></span>
                        <span style="color:#e30613; font-size:1.25rem;">+</span>
                    </summary>
                    <div class="alfa-faq-content">
                        <?php echo esc_html($faq['a']); ?>
                    </div>
                </details>
            <?php endforeach; ?>
        </div>

        <!-- Support Card -->
        <div style="margin-top:3.5rem; background:#0b1429; border:1px solid rgba(255,255,255,0.1); border-radius:1.5rem; padding:2rem; text-align:center;">
            <h3 style="color:#fff; font-size:1.25rem; font-weight:800; margin:0 0 0.5rem;">لم تجد إجابة لسؤالك؟</h3>
            <p style="color:#94a3b8; font-size:0.85rem; margin:0 0 1.5rem;">تواصل مباشرة مع مستشاري الشحن والدعم اللوجستي وسنرد عليك فوراً.</p>
            <a href="https://wa.me/<?php echo esc_attr(get_option('alfa_whatsapp', '966501653999')); ?>" target="_blank" class="alfa-btn alfa-btn-whatsapp">
                💬 مراسلة الدعم الفني عبر واتساب
            </a>
        </div>

    </div>
</div>

<?php get_footer(); ?>
