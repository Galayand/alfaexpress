<!DOCTYPE html>
<html <?php language_attributes(); ?> dir="rtl">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- MAIN HEADER -->
<header id="alfa-main-header" class="alfa-header">
    <div class="alfa-container">
        <div class="alfa-header-inner">
            
            <!-- LOGO & BRAND -->
            <div style="display:flex; align-items:center;">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="alfa-brand-logo-wrap" style="display:flex; align-items:center; gap:12px; text-decoration:none;">
                    <?php
                    $custom_logo_id = get_theme_mod('custom_logo');
                    $logo_url = $custom_logo_id ? wp_get_attachment_image_url($custom_logo_id, 'medium') : get_template_directory_uri() . '/assets/images/alfa-logo.webp';
                    ?>
                    <div style="width:48px; height:48px; min-width:48px; border-radius:12px; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.12); padding:4px; display:flex; align-items:center; justify-content:center; overflow:hidden; flex-shrink:0;">
                        <img src="<?php echo esc_url($logo_url); ?>" alt="<?php bloginfo('name'); ?>" class="alfa-brand-logo-img" style="max-width:100%; max-height:100%; width:auto; height:auto; object-fit:contain; display:block;">
                    </div>
                    <div>
                        <span style="font-size:1.2rem; font-weight:900; color:#ffffff; display:flex; align-items:center; gap:6px; line-height:1.2;">
                            ألفا إكسبريس
                            <span style="font-size:0.65rem; background:#e30613; color:#fff; padding:2px 6px; border-radius:4px; font-weight:800; text-transform:uppercase;">
                                Logistics
                            </span>
                        </span>
                        <span style="font-size:0.75rem; color:#94a3b8; display:block; margin-top:2px;">
                            <?php echo esc_html(get_option('alfa_legal_name', 'شركة ألفا لنقل العفش والشحن الدولي')); ?>
                        </span>
                    </div>
                </a>
            </div>

            <!-- DESKTOP NAVIGATION -->
            <nav class="alfa-desktop-nav">
                <?php
                if (has_nav_menu('primary')) {
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'container'      => false,
                        'menu_class'     => 'alfa-nav-list',
                        'fallback_cb'    => false,
                    ));
                } else {
                    ?>
                    <ul class="alfa-nav-list">
                        <li class="alfa-nav-item"><a href="<?php echo esc_url(home_url('/')); ?>">الرئيسية</a></li>
                        <li class="alfa-nav-item"><a href="<?php echo esc_url(home_url('/services')); ?>">خدماتنا</a></li>
                        <li class="alfa-nav-item"><a href="<?php echo esc_url(home_url('/branches')); ?>">فروعنا (8)</a></li>
                        <li class="alfa-nav-item"><a href="<?php echo esc_url(home_url('/faq')); ?>">الأسئلة الشائعة</a></li>
                        <li class="alfa-nav-item"><a href="<?php echo esc_url(home_url('/blog')); ?>">المدونة</a></li>
                        <li class="alfa-nav-item"><a href="<?php echo esc_url(home_url('/tracking')); ?>">تتبع الشحنة</a></li>
                        <li class="alfa-nav-item"><a href="<?php echo esc_url(home_url('/quote')); ?>">طلب عرض سعر</a></li>
                    </ul>
                    <?php
                }
                ?>
            </nav>

            <!-- HEADER ACTIONS -->
            <div style="display:flex; align-items:center; gap:10px;">
                <!-- Call Direct -->
                <a href="tel:<?php echo esc_attr(get_option('alfa_main_phone', '0501653999')); ?>" class="alfa-btn alfa-btn-outline alfa-hide-mobile" style="padding:0.5rem 1rem; font-size:0.8rem;" dir="ltr">
                    📞 <?php echo esc_html(get_option('alfa_main_phone', '0501653999')); ?>
                </a>

                <!-- Quick Quote CTA -->
                <a href="<?php echo esc_url(home_url('/quote')); ?>" class="alfa-btn alfa-btn-primary" style="padding:0.55rem 1.25rem; font-size:0.8rem;">
                    اطلب عرض سعر
                </a>

                <!-- Mobile Menu Toggle Button -->
                <button id="alfa-menu-toggle" class="alfa-mobile-toggle-btn alfa-btn alfa-btn-outline" style="padding:0.5rem 0.75rem; font-size:1.1rem;" aria-label="فتح القائمة">
                    ☰
                </button>
            </div>

        </div>

        <!-- MOBILE MENU DRAWER -->
        <div id="alfa-mobile-drawer" style="display:none; padding:1.25rem; margin-top:0.5rem; background:#0b1429; border-radius:1.25rem; border:1px solid rgba(255,255,255,0.1); margin-bottom:1rem;">
            <ul style="list-style:none; padding:0; margin:0; display:grid; grid-template-columns:1fr 1fr; gap:0.5rem;">
                <li><a href="<?php echo esc_url(home_url('/')); ?>" style="display:block; padding:0.6rem; border-radius:0.5rem; background:rgba(255,255,255,0.05); text-align:center; font-weight:bold; font-size:0.85rem; color:#fff; text-decoration:none;">الرئيسية</a></li>
                <li><a href="<?php echo esc_url(home_url('/services')); ?>" style="display:block; padding:0.6rem; border-radius:0.5rem; background:rgba(255,255,255,0.05); text-align:center; font-weight:bold; font-size:0.85rem; color:#fff; text-decoration:none;">خدماتنا</a></li>
                <li><a href="<?php echo esc_url(home_url('/branches')); ?>" style="display:block; padding:0.6rem; border-radius:0.5rem; background:rgba(255,255,255,0.05); text-align:center; font-weight:bold; font-size:0.85rem; color:#fff; text-decoration:none;">فروعنا (8)</a></li>
                <li><a href="<?php echo esc_url(home_url('/faq')); ?>" style="display:block; padding:0.6rem; border-radius:0.5rem; background:rgba(255,255,255,0.05); text-align:center; font-weight:bold; font-size:0.85rem; color:#fff; text-decoration:none;">الأسئلة الشائعة</a></li>
                <li><a href="<?php echo esc_url(home_url('/blog')); ?>" style="display:block; padding:0.6rem; border-radius:0.5rem; background:rgba(255,255,255,0.05); text-align:center; font-weight:bold; font-size:0.85rem; color:#fff; text-decoration:none;">المدونة</a></li>
                <li><a href="<?php echo esc_url(home_url('/tracking')); ?>" style="display:block; padding:0.6rem; border-radius:0.5rem; background:rgba(255,255,255,0.05); text-align:center; font-weight:bold; font-size:0.85rem; color:#fff; text-decoration:none;">تتبع الشحنة</a></li>
                <li style="grid-column:1 / -1;"><a href="<?php echo esc_url(home_url('/quote')); ?>" style="display:block; padding:0.75rem; border-radius:0.5rem; background:#e30613; text-align:center; font-weight:bold; font-size:0.9rem; color:#fff; text-decoration:none;">طلب عرض سعر فوري</a></li>
            </ul>
        </div>
    </div>
</header>
