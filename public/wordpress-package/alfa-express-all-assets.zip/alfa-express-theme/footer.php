<?php
/**
 * Alfa Express Logistics - Footer Template
 */
if (!defined('ABSPATH')) exit;
?>

<!-- MAIN FOOTER -->
<footer style="background:#050a17; border-top:1px solid rgba(255,255,255,0.08); padding-top:4rem; padding-bottom:5rem; color:#94a3b8; font-size:0.875rem;">
    <div class="alfa-container">
        
        <div class="alfa-grid-4" style="margin-bottom:3rem; gap:2rem;">
            
            <!-- COL 1: BRAND INFO -->
            <div>
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:1rem;">
                    <div style="width:40px; height:40px; border-radius:10px; background:rgba(255,255,255,0.05); padding:3px; display:flex; align-items:center; justify-content:center;">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/alfa-logo.webp" alt="Alfa Express" style="max-width:100%; max-height:100%; object-fit:contain;">
                    </div>
                    <div>
                        <span style="font-size:1.1rem; font-weight:900; color:#fff; display:block;">ألفا إكسبريس</span>
                        <span style="font-size:0.7rem; color:#64748b;"><?php echo esc_html(get_option('alfa_legal_name', 'شركة ألفا لنقل العفش والشحن الدولي')); ?></span>
                    </div>
                </div>
                <p style="font-size:0.8rem; line-height:1.7; color:#64748b; margin-bottom:1.5rem;">
                    شحن دولي متكامل من السعودية لكافة محافظات مصر. تغليف معتمد، أمان 100%، وخبرة تمتد لأكثر من 15 عاماً.
                </p>
                <div style="display:flex; gap:0.5rem;">
                    <a href="<?php echo esc_url(home_url('/quote')); ?>" class="alfa-btn alfa-btn-primary" style="padding:0.5rem 1rem; font-size:0.75rem;">
                        طلب عرض سعر
                    </a>
                    <a href="<?php echo esc_url(home_url('/tracking')); ?>" class="alfa-btn alfa-btn-outline" style="padding:0.5rem 1rem; font-size:0.75rem;">
                        تتبع شحنتك
                    </a>
                </div>
            </div>

            <!-- COL 2: QUICK LINKS -->
            <div>
                <h4 style="color:#fff; font-size:1rem; font-weight:800; margin-bottom:1.25rem; display:flex; align-items:center; gap:6px;">
                    <span style="width:6px; height:6px; border-radius:50%; background:#e30613; display:inline-block;"></span>
                    <span>صفحات الموقع</span>
                </h4>
                <ul style="list-style:none; padding:0; margin:0; line-height:2.2; font-size:0.85rem;">
                    <li><a href="<?php echo home_url('/'); ?>" style="color:#94a3b8; transition:color 0.2s;">الرئيسية</a></li>
                    <li><a href="<?php echo home_url('/services'); ?>" style="color:#94a3b8; transition:color 0.2s;">خدمات الشحن</a></li>
                    <li><a href="<?php echo home_url('/branches'); ?>" style="color:#94a3b8; transition:color 0.2s;">فروعنا في المملكة (8)</a></li>
                    <li><a href="<?php echo home_url('/faq'); ?>" style="color:#94a3b8; transition:color 0.2s;">الأسئلة الشائعة</a></li>
                    <li><a href="<?php echo home_url('/blog'); ?>" style="color:#94a3b8; transition:color 0.2s;">المدونة اللوجستية</a></li>
                    <li><a href="<?php echo home_url('/tracking'); ?>" style="color:#94a3b8; transition:color 0.2s;">تتبع الشحنة</a></li>
                </ul>
            </div>

            <!-- COL 3: SHIPPING SERVICES -->
            <div>
                <h4 style="color:#fff; font-size:1rem; font-weight:800; margin-bottom:1.25rem; display:flex; align-items:center; gap:6px;">
                    <span style="width:6px; height:6px; border-radius:50%; background:#e30613; display:inline-block;"></span>
                    <span>خدماتنا المعتمدة</span>
                </h4>
                <ul style="list-style:none; padding:0; margin:0; line-height:2.2; font-size:0.85rem; color:#94a3b8;">
                    <li>شحن الأغراض الشخصية والحقائب</li>
                    <li>شحن الأثاث والعفش المنزلي</li>
                    <li>شحن الأجهزة الكهربائية والشاشات</li>
                    <li>شحن البضائع والطرود التجارية</li>
                    <li>التخليص الجمركي في الموانئ</li>
                    <li>التوصيل من الباب إلى الباب</li>
                </ul>
            </div>

            <!-- COL 4: CONTACT & BRANCHES -->
            <div>
                <h4 style="color:#fff; font-size:1rem; font-weight:800; margin-bottom:1.25rem; display:flex; align-items:center; gap:6px;">
                    <span style="width:6px; height:6px; border-radius:50%; background:#e30613; display:inline-block;"></span>
                    <span>التواصل والفروع</span>
                </h4>
                <div style="display:flex; flex-direction:column; gap:0.75rem; font-size:0.85rem;">
                    <a href="tel:<?php echo esc_attr(get_option('alfa_main_phone', '0501653999')); ?>" style="display:flex; align-items:center; gap:8px; background:rgba(255,255,255,0.05); padding:10px 14px; border-radius:12px; color:#fff; font-weight:bold;" dir="ltr">
                        📞 <?php echo esc_html(get_option('alfa_main_phone', '0501653999')); ?>
                    </a>
                    <a href="https://wa.me/<?php echo esc_attr(get_option('alfa_whatsapp', '966501653999')); ?>" target="_blank" style="display:flex; align-items:center; gap:8px; background:rgba(37,211,102,0.15); padding:10px 14px; border-radius:12px; color:#4ade80; font-weight:bold;">
                        💬 واتساب خدمة العملاء
                    </a>
                    <p style="margin:0; font-size:0.75rem; color:#64748b; line-height:1.6;">
                        📍 المقر الرئيسي: <?php echo esc_html(get_option('alfa_main_address', '4275 الروضة - حي الفيصلية - جدة')); ?>
                    </p>
                </div>
            </div>

        </div>

        <!-- COPYRIGHT -->
        <div style="padding-top:2rem; border-top:1px solid rgba(255,255,255,0.06); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem; font-size:0.75rem; color:#64748b;">
            <p style="margin:0;">
                جميع الحقوق محفوظة © <?php echo date('Y'); ?> ألفا إكسبريس - <?php echo esc_html(get_option('alfa_legal_name', 'شركة ألفا لنقل العفش والشحن الدولي')); ?>
            </p>
            <p style="margin:0;">
                قالب ووردبريس مستقل ومطور بالكامل (Alfa Express Theme v3.0)
            </p>
        </div>

    </div>
</footer>

<!-- STICKY MOBILE CONVERSION DOCK -->
<div class="alfa-mobile-dock">
    <a href="tel:<?php echo esc_attr(get_option('alfa_main_phone', '0501653999')); ?>" class="alfa-btn alfa-btn-outline" style="flex:1; padding:0.6rem 0.5rem; font-size:0.75rem;">
        📞 اتصال فوري
    </a>
    <a href="https://wa.me/<?php echo esc_attr(get_option('alfa_whatsapp', '966501653999')); ?>" target="_blank" class="alfa-btn alfa-btn-whatsapp" style="flex:1; padding:0.6rem 0.5rem; font-size:0.75rem;">
        💬 واتساب
    </a>
    <a href="<?php echo esc_url(home_url('/quote')); ?>" class="alfa-btn alfa-btn-primary" style="flex:1; padding:0.6rem 0.5rem; font-size:0.75rem;">
        ⚡ اطلب تسعيرة
    </a>
</div>

<!-- BACK TO TOP FLOATING BUTTON -->
<button id="alfa-back-to-top" class="alfa-back-to-top" aria-label="العودة للأعلى">
    ↑
</button>

<?php wp_footer(); ?>
</body>
</html>
